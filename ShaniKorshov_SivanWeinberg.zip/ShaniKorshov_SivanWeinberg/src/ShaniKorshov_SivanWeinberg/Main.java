package ShaniKorshov_SivanWeinberg;

import ShaniKorshov_SivanWeinberg.controller.Controller;
import ShaniKorshov_SivanWeinberg.model.CompanyProgram;
import ShaniKorshov_SivanWeinberg.view.View;
import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) throws Exception {
		
		CompanyProgram theModel = new CompanyProgram(); 
		View theView = new View(primaryStage);
		Controller controller = new Controller(theModel, theView);
	}

	public static void main(String[] args) {
		launch(args);
	}


}
