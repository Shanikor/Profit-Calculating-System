package ShaniKorshov_SivanWeinberg.model;


public class departmentAlreadyExistsException extends Exception {
	
	public departmentAlreadyExistsException(String msg) {
		super(msg);
	}
	public departmentAlreadyExistsException() {
		super("This department already exists! Try again.");
	}

}
