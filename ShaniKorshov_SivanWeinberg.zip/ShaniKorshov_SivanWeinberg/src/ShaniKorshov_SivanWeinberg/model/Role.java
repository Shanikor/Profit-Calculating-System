package ShaniKorshov_SivanWeinberg.model;

import java.io.Serializable;
import java.util.Vector;

public class Role implements Changeable, Serializable, Synchronizable {

	private String name;
	private Vector<Employee> employees;
	private boolean isChangable;
	private boolean isSynchronizable;

	public Role(String name, boolean isChangable, boolean isSynchronizable) {
		this.name = name;
		employees = new Vector<Employee>();
		this.isChangable = isChangable;
		this.isSynchronizable = isSynchronizable;
	}

	// change work hours for all employees by role - if the role is 'changeable'
	public void changeHoursForRole(int startHour) {

		for (int i = 0; i < employees.size(); i++) {
			if (employees.get(i) != null) {
				employees.get(i).setStartingHour(startHour);
			}
		}
	}

	// set work from home

	public void setWorkFromHomeForRole(boolean workFromHome) {

		for (int i = 0; i < employees.size(); i++) {
			if (employees.get(i) != null) {
				employees.get(i).setWorkFromHome(workFromHome);
			}
		}
	}

	// getters
	public String getName() {
		return name;
	}

	public Vector<Employee> getEmployees() {
		return employees;
	}

	// Synchronizable methods
	@Override
	public boolean returnIsSynchronizable() {
		return isSynchronizable;
	}

	// Changeable methods
	@Override
	public boolean returnIsChangeable() {
		return isChangable;
	}

	// equals method
	@Override
	public boolean equals(Object other) {
		if (!(other instanceof Role))
			return false;
		Role r = (Role) other;
		return ((this.name.equals(r.getName())) && (this.employees.equals(r.getEmployees())));
	}

	// toString method
	@Override
	public String toString() {
		StringBuffer departmentToString = new StringBuffer();

		departmentToString.append(
				"\n---Role: " + name + "---\nRole working hours are " + (isChangable ? "" : "not ") + "changable");
		departmentToString.append("\nAll employees in this role: ");
		for (int i = 0; i < employees.size(); i++) {
			departmentToString.append("\n" + employees.get(i).toString());

		}
		return departmentToString.toString();
	}

}
