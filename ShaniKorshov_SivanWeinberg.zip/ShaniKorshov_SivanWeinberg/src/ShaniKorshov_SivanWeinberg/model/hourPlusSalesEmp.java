package ShaniKorshov_SivanWeinberg.model;

import java.io.Serializable;

public class hourPlusSalesEmp extends Employee implements Serializable{

	private double baseSelery;
	private double percentegeOfSales;
	private double salary;
	private int amountOfSales;

	public hourPlusSalesEmp(String name, String id, int preferenceNum, int percentegeOfSales, int baseSelery,
			int amountOfSales, boolean isChangeable, boolean isSynchronizable, int departmentStartingHour) {
		super(name, id, preferenceNum,isChangeable, isSynchronizable,departmentStartingHour);
		this.percentegeOfSales = percentegeOfSales;
		this.baseSelery = baseSelery;
		this.amountOfSales = amountOfSales;
		salary = baseSelery + ((percentegeOfSales / 100) * amountOfSales);
	}

	// getters
	public double getBaseSelery() {
		return baseSelery;
	}

	public double getPercentegeOfSales() {
		return percentegeOfSales;
	}

	public int getAmountOfSales() {
		return amountOfSales;
	}

	public double getSalary() {
		return salary;
	}

	// toString method
	@Override
	public String toString() {
		return (super.toString() + " \nEmployee gets paid by base salary plus sales. \nSalary for this month: " + salary
				+ " NIS.\nBase salary" + baseSelery + " \nPercentege of sales: " + percentegeOfSales
				+ " Amount of sales this month:" + amountOfSales);
	}

}
