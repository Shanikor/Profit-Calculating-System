package ShaniKorshov_SivanWeinberg.model;

import java.io.Serializable;

public class Preference implements Serializable {
	private int preferenceNum;

	public Preference(int preferenceNum) {
		this.preferenceNum= preferenceNum; 
	}
	// getters

	public int getPreferenceNum() {
		return preferenceNum;
	}

	// equals method
	@Override
		public boolean equals(Object other) {
			if (!(other instanceof Preference))
				return false;
			Preference p = (Preference) other;
			return (this.preferenceNum==(p.getPreferenceNum()));
		}
	// toString method
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("\nPreference: ");
		if(preferenceNum==0)
			sb.append("Start working earlier than 8:00 AM\n");
		else if(preferenceNum==1)
			sb.append("Start working later than 8:00 AM\n");
		else if(preferenceNum==2)
			sb.append("remain with current working hours\n");
		else 
			sb.append("Work from home\n");
		return sb.toString();
	}
}
