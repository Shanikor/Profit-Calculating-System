package ShaniKorshov_SivanWeinberg.model;

public interface Changeable {
	boolean returnIsChangeable();
}
