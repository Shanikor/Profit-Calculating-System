package ShaniKorshov_SivanWeinberg.model;

public class percentageException extends Exception {
	public percentageException(String msg) {
		super(msg);
	}
	public percentageException() {
		super("Percentage value must be between 0-100!");
	}

}
