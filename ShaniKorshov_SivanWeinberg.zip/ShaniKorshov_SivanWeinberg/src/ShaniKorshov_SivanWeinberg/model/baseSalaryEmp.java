package ShaniKorshov_SivanWeinberg.model;

import java.io.Serializable;

public class baseSalaryEmp extends Employee implements Serializable {

	private final int hoursPerMonth = 160;
	private double salaryPerMonth;

	public baseSalaryEmp(String name, String id, int preferenceNum, int salaryPerMonth, boolean isChangeable, boolean isSynchronizable, int departmentStartingHour ) {
		super(name, id, preferenceNum, isChangeable, isSynchronizable,departmentStartingHour);
		this.salaryPerMonth = salaryPerMonth;
	}

	// getters
	public double getSalaryPerMonth() {
		return salaryPerMonth;
	}

	// toString method
	@Override
	public String toString() {
		return (super.toString() + "Employee gets paid by base salary. Salary per month: " + salaryPerMonth + " NIS.\n");
	}

}
