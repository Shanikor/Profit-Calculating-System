package ShaniKorshov_SivanWeinberg.model;

import java.io.Serializable;
import java.util.Vector;
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class Company implements Serializable {

	private static DecimalFormat df2 = new DecimalFormat("#.##");

	private String name;
	private Vector<Department> departments;
	private double avgPerEmployee;
	private double totalRevenue;

	public Company(String name, double avgPerWorker) {
		this.name = name;
		departments = new Vector<Department>();
		this.avgPerEmployee = avgPerWorker;
		totalRevenue = 0;
	}

	// create new department
	public boolean createNewDepartment(String name, boolean isChangable, boolean isSynchronizable) {

		for (int i = 0; i < departments.size(); i++) {
			if (departments.get(i) != null) {
				if ((departments.get(i).getName()).equals(name))
					return false;
			}
		}
		departments.add(new Department(name, isChangable, isSynchronizable));
		return true;
	}

	// check if user can create role (only if there is at least one department in
	// the company)
	public boolean canCreateRole() {
		if (departments.get(0) == null)
			return false;
		else
			return true;
	}

	// create new role
	public boolean createNewRole(String name, boolean isChangable, String departmentName) {

		// find wanted department
		for (int i = 0; i < departments.size(); i++) {
			if ((departments.get(i) != null) && (departments.get(i).getName().equals(departmentName))) {
				boolean synchronizable = departments.get(i).returnIsSynchronizable();
				for (int j = 0; j < departments.get(i).getRoles().size(); j++) {
					if (departments.get(i).getRoles().get(j).getName().equals(name))
						return false;
				}
				departments.get(i).getRoles().add(new Role(name, isChangable, synchronizable));
			}
		}
		return true;
	}

	// check if user can create employee (only if there is at least one role in the
	// company)
	public boolean canCreateEmployee() {
		boolean atLeastOneRole = false;
		for (int i = 0; i < departments.size(); i++) {
			if (!(departments.get(i).getRoles().isEmpty())) {
				atLeastOneRole = true;
				if (atLeastOneRole)
					return atLeastOneRole;
			}
		}
		return atLeastOneRole;
	}

	// create new employee
	public boolean createEmployee(String name, String id, int salaryCalculation, String departmentName, String roleName,
			int preferenceNum, int percentegeOfSales, int salary, int revenueOfSales) {

		boolean exist = false;
		for (int i = 0; i < departments.size(); i++) {
			exist = departments.get(i).isEmployeeExist(id);
			if (exist)
				return false; // if Employee is already exist in a department - can't add it again!
		}

		// Employee is'nt exist -> find wanted department
		for (int i = 0; i < departments.size(); i++) {
			if ((departments.get(i) != null) && (departments.get(i).getName().equals(departmentName))) {
				
				boolean changeable = departments.get(i).returnIsChangeable();
				boolean synchronizable = departments.get(i).returnIsSynchronizable();
				int departmentStartingHour=8;
				
				if (synchronizable) {
					if(departments.get(i).getRoles().get(0).getEmployees().size()==0)
						departmentStartingHour=8;
					else departmentStartingHour =departments.get(i).getRoles().get(0).getEmployees().get(0).getStartingHour();			
				}
				else departmentStartingHour=8;
				
				// find wanted role in the department
				for (int j = 0; j < departments.get(i).getRoles().size(); j++) {

					if ((departments.get(i).getRoles() != null)
							&& (departments.get(i).getRoles().get(j).getName().equals(roleName))) {

						// for the right role, in the right department - and this employee

						 
						if (salaryCalculation == 0) {
							departments.get(i).getRoles().get(j).getEmployees()
									.add(new baseSalaryEmp(name, id, preferenceNum, salary,changeable,synchronizable,departmentStartingHour));
						
						} else if (salaryCalculation == 1) {
							departments.get(i).getRoles().get(j).getEmployees()
									.add(new perHourEmp(name, id, preferenceNum, salary,changeable,synchronizable,departmentStartingHour));
						} else if (salaryCalculation == 2) {
							departments.get(i).getRoles().get(j).getEmployees().add(new hourPlusSalesEmp(name, id,
									preferenceNum, percentegeOfSales, salary, revenueOfSales,changeable,synchronizable,departmentStartingHour));
						}
						
						if (departments.get(i).returnIsSynchronizable()) {
							if(departments.get(i).getRoles().get(0).getEmployees().get(0).isWorkFromHome()) {
								int size = departments.get(i).getRoles().get(j).getEmployees().size();
								departments.get(i).getRoles().get(j).getEmployees().get(size-1).setWorkFromHome(true);
								departments.get(i).getRoles().get(j).getEmployees().get(size-1).setStartingHour(-1);

							}
						}
					
					}
				}
			}
		}
		return true;
	}

	// change work hours for a whole department
	public boolean changeHoursByDepartment(String departmentName, int startingHour, boolean workFromHome)
			throws departmentIsntChangeableException, notAllRolesAreChangeable {
		// first check if the department is 'changeable', if it is, change hours and
		// synchronize if needed
		for (int i = 0; i < departments.size(); i++) {
			if ((departments.get(i) != null) && departments.get(i).getName().equals(departmentName)) {
				if (departments.get(i).returnIsChangeable()) {
					boolean res = departments.get(i).changeMethodForDepartment(startingHour, workFromHome);
					return res; // when starting hour was changed - stop loop
				} else {
					throw new departmentIsntChangeableException();
				}
			}
		}
		return false;
	}

	// change working method for a role
	public boolean changeWorkMethodByRole(String departmentName, String roleName, int startingHour,
			boolean workFromHome)
			throws notAllRolesAreChangeable, departmentIsntChangeableException, roleIsNotChangeable {

		for (int i = 0; i < departments.size(); i++) {
			if ((departments.get(i) != null) && departments.get(i).getName().equals(departmentName)) {
				if (!departments.get(i).returnIsChangeable()) {
					throw new departmentIsntChangeableException();
				} else {
					for (int j = 0; j < departments.get(i).getRoles().size(); j++) {
						if (departments.get(i).getRoles().get(j).getName().equals(roleName)) {

							// check if this Role is 'changeable'
							if (departments.get(i).getRoles().get(j).returnIsChangeable()) {

								// check if department working hours need to be synchronized
								if (departments.get(i).returnIsSynchronizable()) {

									// if need to be synchronized try to change method for whole department
									return departments.get(i).changeMethodForDepartment(startingHour, workFromHome);

								} else {
									// if don't need to be synchronized try to change method only for this role
									if (workFromHome) {
										departments.get(i).getRoles().get(j).setWorkFromHomeForRole(workFromHome);
										departments.get(i).getRoles().get(j).changeHoursForRole(-1);
										return true;
									} else {
										departments.get(i).getRoles().get(j).setWorkFromHomeForRole(workFromHome);
										departments.get(i).getRoles().get(j).changeHoursForRole(startingHour);
										return true;
									}
								}
							} else {
								throw new roleIsNotChangeable();
							}
						}
					}
				}
			}
		}
		return false;

	}

	// calculate revenue
	public String calculateRevenue() {
		StringBuffer str = new StringBuffer();
		// calculate all effective hours and revenue for all employees
		double effectiveness = 0;
		double departmentEffectiveness = 0;

		if (departments.size() != 0) {
			for (int i = 0; i < departments.size(); i++) {

				if (departments.get(i).getRoles().size() != 0) {
					for (int j = 0; j < departments.get(i).getRoles().size(); j++) {
						if (departments.get(i).getRoles().get(j).getEmployees().size() != 0) {
							for (int x = 0; x < departments.get(i).getRoles().get(j).getEmployees().size(); x++) {
								// for each employee, calculate effective hours
								effectiveness += departments.get(i).getRoles().get(j).getEmployees().get(x)
										.effectiveHours();
								str.append("\nEmployees name: "
										+ departments.get(i).getRoles().get(j).getEmployees().get(x).getName());
								str.append("\nThe effect of the change on employees efficiency, in hours: "
										+ df2.format(departments.get(i).getRoles().get(j).getEmployees().get(x)
												.effectiveHours())
										+ " [Hours/Employee]");
								departmentEffectiveness += departments.get(i).getRoles().get(j).getEmployees().get(x)
										.effectiveHours();
							}
						}
					}
				}
				departments.get(i).setEffectiveHours(departmentEffectiveness);
				str.append("\nDepartment name: " + departments.get(i).getName() + "\nDepartment's efficiency: "
						+ df2.format(departmentEffectiveness) + " [Hours/Employee]\n______________________\n");
				departmentEffectiveness = 0;
			}
		}
		str.append("\nTotal company's efficiency, in hours: " + df2.format(effectiveness) + " [Hours/Employee]");
		str.append("\nTotal company's revenue from all employess: " + df2.format(effectiveness * avgPerEmployee)
				+ " NIS.");

		totalRevenue = effectiveness * avgPerEmployee;

		return str.toString();
	}

	// getters
	public String getName() {
		return name;
	}

	public double getAvgPerEmployee() {
		return avgPerEmployee;
	}

	public Vector<Department> getDepartments() {
		return departments;
	}

	public double getTotalRevenue() {
		return totalRevenue;
	}

	// equals method
	@Override
	public boolean equals(Object other) {
		if (!(other instanceof Company))
			return false;
		Company c = (Company) other;
		return (this.name.equals(c.getName()));
	}

	// toString method
	@Override
	public String toString() {
		StringBuffer companyToString = new StringBuffer();
		companyToString.append("\nCompany name: " + name + "\nAverage revenue from each employee : " + avgPerEmployee
				+ "\nCompany's departments:");
		for (int i = 0; i < departments.size(); i++) {
			if (departments.get(i) != null)
				companyToString.append(departments.get(i).toString());
		}
		return companyToString.toString();
	}
}
