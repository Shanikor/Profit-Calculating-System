package ShaniKorshov_SivanWeinberg.model;

public class roleIsAlreadyExists extends Exception {
	
	public roleIsAlreadyExists(String msg) {
		super(msg);
	}
	public roleIsAlreadyExists() {
		super("This role already exists in this department!");
	}

}
