package ShaniKorshov_SivanWeinberg.model;


public class positiveNumberException extends Exception {
	
	public positiveNumberException(String msg) {
		super(msg);
	}
	public positiveNumberException() {
		super("Values must be positive!");
	}

}
