package ShaniKorshov_SivanWeinberg.model;

import java.io.Serializable;
import java.util.Vector;

public class Department implements Changeable, Synchronizable, Serializable {

	private String name;
	private Vector<Role> roles;
	private boolean isChangable;
	private boolean isSynchronizable;
	private double departmentEffectiveHours;

	public Department(String name, boolean isChangable, boolean isSynchronizable) {
		this.name = name;
		roles = new Vector<Role>();
		this.isChangable = isChangable;
		this.isSynchronizable = isSynchronizable;
		departmentEffectiveHours = 0;
	}

	public boolean isEmployeeExist(String id) {
		boolean exist = false;

		for (int i = 0; i < roles.size(); i++) {
			for (int j = 0; j < roles.get(i).getEmployees().size(); j++) {
				if ((roles.get(i).getEmployees() != null) && (roles.get(i).getEmployees().get(j).getId().equals(id)))
					exist = true;
			}
		}
		return exist;
	}

	// change working method to all employees in the department
	public boolean changeMethodForDepartment(int startHour, boolean workFromHome) throws notAllRolesAreChangeable {

		// change all roles in the department to work from home method.roles that can't
		// change working hours will work in the same hours - but from home.

		// check if all roles in the department are changeable
		boolean rolesAreChangeable = true;
		for (int i = 0; i < roles.size(); i++) {
			if (roles.get(i) != null) {
				rolesAreChangeable = roles.get(i).returnIsChangeable();
				if (!rolesAreChangeable) {
					throw new notAllRolesAreChangeable();
				}
			}
		}
		if (rolesAreChangeable) {

			if (workFromHome) {
				for (int i = 0; i < roles.size(); i++) {
					if (roles.get(i) != null) {
						roles.get(i).setWorkFromHomeForRole(workFromHome);
						roles.get(i).changeHoursForRole(-1);
					}
				}
				return true;
			} else {
				for (int i = 0; i < roles.size(); i++) {
					if (roles.get(i) != null) {
						roles.get(i).changeHoursForRole(startHour);
						roles.get(i).setWorkFromHomeForRole(workFromHome);
					}
				}
				return true;
			}
		}
		return false;
	}

	// set department effective Hours
	public void setEffectiveHours(double hours) {
		departmentEffectiveHours = hours;
	}

	//Changeable methods 
	@Override
	public boolean returnIsChangeable() {
		return isChangable;
	}

	//Synchronizable methods 
	@Override
	public boolean returnIsSynchronizable() {
		return isSynchronizable;
	}

	// getters
	public String getName() {
		return name;
	}

	public Vector<Role> getRoles() {
		return roles;
	}

	public double getDepartmentEffectiveHours() {
		return departmentEffectiveHours;
	}

	// equals method
	@Override
	public boolean equals(Object other) {
		if (!(other instanceof Department))
			return false;
		Department d = (Department) other;
		return (this.name.equals(d.getName()));
	}

	// toString method
	@Override
	public String toString() {
		StringBuffer departmentToString = new StringBuffer();

		departmentToString.append("\n\n--------Department: " + name + "--------\nDepartment working hours are "
				+ (isChangable ? "" : "not " ) + "changable");
		departmentToString
				.append("\nDepartment working hours are " + (isSynchronizable ? "" : "not ") + "synchronized");
		departmentToString.append("\nAll roles in this department: ");
		for (int i = 0; i < roles.size(); i++) {
			departmentToString.append(roles.get(i).toString());
		}
		return departmentToString.toString();
	}

}
