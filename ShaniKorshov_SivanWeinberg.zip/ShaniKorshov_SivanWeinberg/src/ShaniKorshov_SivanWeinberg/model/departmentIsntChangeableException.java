package ShaniKorshov_SivanWeinberg.model;

public class departmentIsntChangeableException extends Exception {
	
	public departmentIsntChangeableException(String msg) {
		super(msg);
	}
	public departmentIsntChangeableException() {
		super("Department hours aren't changeable!");
	}

}
