package ShaniKorshov_SivanWeinberg.model;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Vector;

import ShaniKorshov_SivanWeinberg.listeners.ModelListenable;

public class CompanyProgram {

	private static Vector<ModelListenable> allListeners = new Vector<ModelListenable>();

	// register listener
	public void registerListener(ModelListenable l) {
		allListeners.add(l);
	}

	private Company company;

	// create company
	public void createCompany(String name, double avgPerWorker) {
		Company company = new Company(name, avgPerWorker); 
		this.company = company;
	}

	// create new department in the company
	public void createDepartment(String name, boolean isChangable, boolean isSynchronizable) throws departmentAlreadyExistsException {
		boolean res = company.createNewDepartment(name, isChangable, isSynchronizable);
		if (!res) {
			throw new departmentAlreadyExistsException();
		}
	}

	// create new role in the company
	public boolean createRole(String name, boolean isChangable, String departmentName) throws roleIsAlreadyExists, onlyLettersAllowedException {

		boolean onlyLetters = true;
		for (int i = 0; i < name.length(); i++) {
			if (!(((int) name.charAt(i) >= 65 && (int) name.charAt(i) <= 90)
					|| ((int) name.charAt(i) >= 97 && (int) name.charAt(i) <= 122) || ((int) name.charAt(i) == 32))) {
				onlyLetters = false;

			}
		}
		if (!onlyLetters) {
			throw new onlyLettersAllowedException();
		} else {
			boolean res = company.createNewRole(name, isChangable, departmentName);
			if (!res) {
			   throw new roleIsAlreadyExists();
			}
			return res;
		}
	}

	// create new employee
	public boolean createEmployee(String name, String id, int salaryCalculation, String departmentName, String roleName,
			int preferenceNum, int percentageOfSales, int salary, int revenueOfSales) throws onlyLettersAllowedException, employeeIsAlreadyExists, nineDigitsIdException, onlyDigitsIdException, positiveNumberException, percentageException {

		boolean onlyLetters = true;
		boolean onlyDigits = true;
		// check if name contains only letters
		for (int i = 0; i < name.length(); i++) {
			if (!(((int) name.charAt(i) >= 65 && (int) name.charAt(i) <= 90)
					|| ((int) name.charAt(i) >= 97 && (int) name.charAt(i) <= 122) || ((int) name.charAt(i) == 32))) {
				onlyLetters = false;
				if (!onlyLetters) {
					throw new onlyLettersAllowedException();
				}
			}
		}

		// check if id contains 9 digits
		if (id.length() != 9) {
			throw new nineDigitsIdException();
		} else {
			for (int i = 0; i < id.length(); i++) {
				if (!(((int) id.charAt(i) >= 48 && (int) id.charAt(i) <= 57))) {
					onlyDigits = false;
					if (!onlyDigits) {
						throw new onlyDigitsIdException();
					}
				}
			}

		}

		// check if salary value is legal (positive number)
		if (salary < 0) {
			throw new positiveNumberException();
		}

		// check if percentage of Sales is legal (0-100)
		if (percentageOfSales < 0 || percentageOfSales > 100) {
			throw new percentageException();
		}

		// check if revenue value is legal (positive number)
		if (revenueOfSales < 0) {
			throw new positiveNumberException();
		}

		boolean res = company.createEmployee(name, id, salaryCalculation, departmentName, roleName, preferenceNum,
				percentageOfSales, salary, revenueOfSales);
		if (!res) {
			throw new employeeIsAlreadyExists();
		}
		return res;
	}

	// change working method for a whole department
	public boolean changeHoursByDep(String departmentName, int startingHour, boolean workFromHome)
			throws departmentIsntChangeableException, notAllRolesAreChangeable {
		return company.changeHoursByDepartment(departmentName, startingHour, workFromHome);
	}

	// change working method for a role
	public boolean changeHoursByRole(String departmentName, String roleName, int startingHour, boolean workFromHome)
			throws notAllRolesAreChangeable, departmentIsntChangeableException, roleIsNotChangeable {
		return company.changeWorkMethodByRole(departmentName, roleName, startingHour, workFromHome);
	}

	// calculate company revenue
	public String calculateCompanyRevenue() {
		return company.calculateRevenue();
	}
	
	// get company's revenue
	public double getCompanysRevenue() {
		return company.getTotalRevenue();
	}

	// get company's information
	public String getCompanysInfo() {
		return company.toString();
	}

	// send message to view
	public void sentMsgToShowForView(String msg) {
		for (ModelListenable l : allListeners)
			l.sentMsgToShowForView(msg);
	}

	// get departments
	public Vector<Department> getDepartments() {
		return company.getDepartments();
	}

	// get can create role
	public boolean canCreateRole() {
		return company.canCreateRole();
	}

	// get can create employee
	public boolean canCreateEmp() {
		return company.canCreateEmployee();
	}
	

	// check if there is a file - if yes, load it to company object.

	public void loadFile() throws IOException, ClassNotFoundException {
			ObjectInputStream inFile = new ObjectInputStream(new FileInputStream("companySimulation.dat"));
			company = (Company) inFile.readObject();
			inFile.close();
		
	}

	// save program to file
	public void saveProgramToFile() throws IOException {
		// write company object to file
		ObjectOutputStream outFile = new ObjectOutputStream(new FileOutputStream("companySimulation.dat"));
		outFile.writeObject(company);
		outFile.close();
	}
}
