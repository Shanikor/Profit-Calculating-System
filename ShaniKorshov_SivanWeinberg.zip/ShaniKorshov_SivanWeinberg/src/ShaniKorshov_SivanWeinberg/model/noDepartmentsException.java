package ShaniKorshov_SivanWeinberg.model;


public class noDepartmentsException extends Exception {
	
	public noDepartmentsException(String msg) {
		super(msg);
	}
	public noDepartmentsException() {
		super("There are no departments in the company!");
	}

}
