package ShaniKorshov_SivanWeinberg.model;

import java.io.Serializable;

public class perHourEmp extends Employee implements Serializable {

	private int salaryPerHour;

	public perHourEmp(String name, String id, int preferenceNum, int salaryPerHour, boolean isChangeable, boolean isSynchronizable, int departmentStartingHour) {
		super(name, id, preferenceNum, isChangeable, isSynchronizable, departmentStartingHour);
		this.salaryPerHour = salaryPerHour;
	}
	// getters

	public int getSalaryPerHour() {
		return salaryPerHour;
	}

	// toString method
	@Override
	public String toString() {
		return (super.toString() + "Employee gets paid per hour. Salary per hour: " + salaryPerHour + " NIS.\n" );
	}

}
