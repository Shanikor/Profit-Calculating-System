package ShaniKorshov_SivanWeinberg.model;

import java.io.Serializable;

public abstract class Employee implements Serializable, Changeable, Synchronizable {

	protected String name;
	protected String id;
	protected int startingHour;
	protected Preference preference;
	protected boolean workFromHome;
	protected double employeeRevenue;
	protected boolean isChangeable;
	protected boolean isSynchronizable;


	public Employee(String name, String id, int preferenceNum, boolean isChangeable, boolean isSynchronizable, int departmentStartingHour) {
		this.name = name;
		this.id = id;
		setPrimaryStartingHour(isSynchronizable, departmentStartingHour);
		preference = new Preference(preferenceNum);
		workFromHome = false;
		employeeRevenue = 0;
		this.isChangeable = isChangeable;
		this.isSynchronizable = isSynchronizable;
	}

	//set starting hour - if employee is working in a 'Synchronizable' department-
	//his starting hour needs to be synchronized with department working hours! 
	
	public void setPrimaryStartingHour(boolean isSynchronizable , int departmentsStartingHour) {
		if (!isSynchronizable)
			this.startingHour = 8;
		else {
			this.startingHour = departmentsStartingHour;
		}
		
	}
	
	// calculate change efficiency
	public double effectiveHours() {
		if (preference.getPreferenceNum() == 0) { // employee prefers to start working earlier
			if (workFromHome) {
				employeeRevenue = 8 * 0.2;
				return employeeRevenue; // if employee wants to work earlier then 8, he can work from home in any hour
										// as
										// he wants
			} else {
				if (startingHour >= 17) {
					employeeRevenue = -8 * 0.2; //starting after 17:00, employee has 8 inefficient hours
				    return employeeRevenue;
				} else {
					employeeRevenue = (8 - startingHour) * (0.2);
					return employeeRevenue;
				}
			}
		} else if (preference.getPreferenceNum() == 1) { // employee prefers to start working later
			if (workFromHome) {
				employeeRevenue = 8 * 0.2; 
				return employeeRevenue; // if employee wants to work later then 8, he can work from home in any hour as
										// he wants
			} else {
				if (startingHour >= 17) {
					employeeRevenue = 8 * 0.2;  //starting after 17:00, employee has 8 efficient hours
					return employeeRevenue;
				} else {
					employeeRevenue = (startingHour - 8) * (0.2);
					return employeeRevenue;
				}

			}

		} else if (preference.getPreferenceNum() == 2) { // employee wants to remain with current hours
			if (workFromHome)
				return 0.2*8; // if he works from home he can work in 8:00-17:00!  
			else {
				if (startingHour < 8) {
					employeeRevenue = ((startingHour-8) * (0.2)) + (startingHour*0.2);
					return employeeRevenue;
				} else if (startingHour > 8) {
					if(startingHour >=17) {
						employeeRevenue = -8 * 0.2; //starting after 17:00, employee has 8 inefficient hours
					    return employeeRevenue;
					}
					else {
						employeeRevenue = ((8- startingHour) * (0.2))+ ((8-(startingHour-8))*0.2);
						return employeeRevenue;
					}
				} else { // startingHour==8
					employeeRevenue = 8*0.2;
					return employeeRevenue;
				}
			}

		} else { // preference.getPreferenceNum() == 3 , employee wants to work from home
			if (isWorkFromHome()) {
				employeeRevenue = 8 * 0.1;
				return employeeRevenue;
			}
			if (!isWorkFromHome()) {
				employeeRevenue = -8 * 0.2;
				return employeeRevenue;
			}
		}
		return employeeRevenue; // Preference can only be between 0-3
	}

	// getters
	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}

	public int getStartingHour() {
		return startingHour;
	}

	public Preference getPreference() {
		return preference;
	}

	public boolean isWorkFromHome() {
		return workFromHome;
	}
	
	//Synchronizable methods
	
	public boolean returnIsSynchronizable() {
		return isSynchronizable;
	}

	//Changeable methods
	
	public boolean returnIsChangeable() {
		return isChangeable;
	}

	// setters

	// set new starting hour for employee
	public void setStartingHour(int startingHour) {
		this.startingHour = startingHour;
	}

	// set work from home for employee
	public void setWorkFromHome(boolean workFromHome) {
		this.workFromHome = workFromHome;
	}

	// equals method
	@Override
	public boolean equals(Object other) {
		if (!(other instanceof Employee))
			return false;
		Employee e = (Employee) other;
		return ((this.name.equals(e.getName())) && (this.id.equals(e.getId())));
	}

	// toString method
	@Override
	public String toString() {
		return "\nEmployee name: " + name + "\nEmployee id: " + id + (workFromHome ? "\nWorks from home."
				: "\nStarts working at " + startingHour + ":00." ) + preference.toString();
	}

}
