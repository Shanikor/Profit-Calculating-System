package ShaniKorshov_SivanWeinberg.model;

public class employeeIsAlreadyExists extends Exception {
	
	public employeeIsAlreadyExists(String msg) {
		super(msg);
	}
	public employeeIsAlreadyExists() {
		super("Employee with this id already exists! ");
	}

}
