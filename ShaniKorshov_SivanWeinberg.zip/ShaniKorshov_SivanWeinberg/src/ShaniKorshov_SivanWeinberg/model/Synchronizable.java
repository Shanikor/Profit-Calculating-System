package ShaniKorshov_SivanWeinberg.model;

public interface Synchronizable {
	boolean returnIsSynchronizable();	
}
