package ShaniKorshov_SivanWeinberg.model;

public class notAllRolesAreChangeable extends Exception {
	
	public notAllRolesAreChangeable(String msg) {
		super(msg);
	}
	public notAllRolesAreChangeable() {
		super("Not all roles in the department are changeable!\nCan't change working hours.");
	}

}
