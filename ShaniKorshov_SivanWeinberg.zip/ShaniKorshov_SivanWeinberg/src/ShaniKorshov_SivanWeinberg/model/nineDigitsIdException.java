package ShaniKorshov_SivanWeinberg.model;

public class nineDigitsIdException extends Exception {
	public nineDigitsIdException(String msg) {
		super(msg);
	}
	public nineDigitsIdException() {
		super("Id must contain 9 digits");
	}

}
