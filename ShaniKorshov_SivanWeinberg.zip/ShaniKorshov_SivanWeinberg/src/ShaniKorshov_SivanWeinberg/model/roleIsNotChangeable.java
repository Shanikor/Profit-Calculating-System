package ShaniKorshov_SivanWeinberg.model;


public class roleIsNotChangeable extends Exception {
	
	public roleIsNotChangeable(String msg) {
		super(msg);
	}
	public roleIsNotChangeable() {
		super("Role working hours aren't changeable!");
	}

}
