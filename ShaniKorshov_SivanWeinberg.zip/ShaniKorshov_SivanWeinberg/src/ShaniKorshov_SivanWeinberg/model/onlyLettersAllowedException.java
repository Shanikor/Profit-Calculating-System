package ShaniKorshov_SivanWeinberg.model;

public class onlyLettersAllowedException extends Exception {
	public onlyLettersAllowedException(String msg) {
		super(msg);
	}
	public onlyLettersAllowedException() {
		super("Invalid input! only letters are allowed!");
	}

}
