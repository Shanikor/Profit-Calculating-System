package ShaniKorshov_SivanWeinberg.model;

public class onlyDigitsIdException extends Exception {
	
	public onlyDigitsIdException(String msg) {
		super(msg);
	}
	public onlyDigitsIdException() {
		super("Id must contain only digits!");
	}

}
