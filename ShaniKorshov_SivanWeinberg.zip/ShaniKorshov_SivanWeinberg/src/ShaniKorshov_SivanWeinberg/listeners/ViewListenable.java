package ShaniKorshov_SivanWeinberg.listeners;

import java.io.IOException;
import java.util.Vector;

import ShaniKorshov_SivanWeinberg.model.Department;
import ShaniKorshov_SivanWeinberg.model.departmentAlreadyExistsException;
import ShaniKorshov_SivanWeinberg.model.departmentIsntChangeableException;
import ShaniKorshov_SivanWeinberg.model.employeeIsAlreadyExists;
import ShaniKorshov_SivanWeinberg.model.nineDigitsIdException;
import ShaniKorshov_SivanWeinberg.model.notAllRolesAreChangeable;
import ShaniKorshov_SivanWeinberg.model.onlyDigitsIdException;
import ShaniKorshov_SivanWeinberg.model.onlyLettersAllowedException;
import ShaniKorshov_SivanWeinberg.model.percentageException;
import ShaniKorshov_SivanWeinberg.model.positiveNumberException;
import ShaniKorshov_SivanWeinberg.model.roleIsAlreadyExists;
import ShaniKorshov_SivanWeinberg.model.roleIsNotChangeable;

public interface ViewListenable {

	void askModelToCreateCompany(String companyName1, double revenuePerWorker);
	void askModelToCreateDep(String depName, boolean isChangeableAns, boolean isSynchronizableAns) throws departmentAlreadyExistsException;
	String getCompanysInfo();
	Vector<Department> getDepartmentsList();
	boolean sendRoleToModel(String roleName, boolean isSelected, String department) throws roleIsAlreadyExists, onlyLettersAllowedException;
	boolean canCreateEmp();
	boolean sendEmpToModel(String name, String id, int salaryType, String depName, String roleName, int preference,
			int percentage, int salary, int revenue) throws onlyLettersAllowedException, employeeIsAlreadyExists, nineDigitsIdException, onlyDigitsIdException, positiveNumberException, percentageException;
	boolean changeMethodByDep(String departmentName,int startingHour,boolean workFromHome) throws departmentIsntChangeableException, notAllRolesAreChangeable;
	boolean changeMethodByRole(String departmentName2, String roleName2, int startingHour2, boolean workFromHome2) throws notAllRolesAreChangeable, departmentIsntChangeableException, roleIsNotChangeable;
	String getRevenueFromModel();
	void askModelToSaveProgramToFile() throws IOException;
	void askModelToLoadFromFile() throws ClassNotFoundException, IOException;
	double askModelForCompanysRevenue();
}

