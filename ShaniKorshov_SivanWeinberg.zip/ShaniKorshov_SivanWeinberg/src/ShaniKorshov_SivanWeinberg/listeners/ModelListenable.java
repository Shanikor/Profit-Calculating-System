package ShaniKorshov_SivanWeinberg.listeners;

public interface ModelListenable {
	void sentMsgToShowForView(String msg);
}
