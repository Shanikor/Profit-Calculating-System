package ShaniKorshov_SivanWeinberg.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class ShowRevenueScene {

	private Scene showRevenueScene;
	private TextArea companysRevenue;
	private Button backToMenuFromRevenue;
	private VBox vbRootShowRevenue;
	private Label revenueLabel;
	private Label positiveRevenue;
	private Label negativeRevenue;
	private Label revenueIsZero;

	public ShowRevenueScene() {

		// show revenue scene

		vbRootShowRevenue = new VBox();
		vbRootShowRevenue.setPadding(new Insets(15));
		vbRootShowRevenue.setSpacing(10);
		vbRootShowRevenue.setAlignment(Pos.CENTER);
		vbRootShowRevenue.setBackground(new Background(new BackgroundFill(Color.GHOSTWHITE, null, null)));

		showRevenueScene = new Scene(vbRootShowRevenue, 550, 380);

		revenueLabel = new Label("Company's revenue for current changes:");
		revenueLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.ITALIC, 30));

		companysRevenue = new TextArea();
		companysRevenue.setEditable(false);

		positiveRevenue = new Label("The profit is positive, current change is recommended!");
		positiveRevenue.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 18));
		positiveRevenue.setTextFill(Color.GREEN);

		negativeRevenue = new Label("The change you chose reduces the company's revenue.");
		negativeRevenue.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 18));
		negativeRevenue.setTextFill(Color.CRIMSON);

		revenueIsZero = new Label("The current change has no effect on the company's profits.");
		revenueIsZero.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 18));
		revenueIsZero.setTextFill(Color.ROYALBLUE);

		backToMenuFromRevenue = new Button("Back");
		backToMenuFromRevenue.setStyle("-fx-background-color: #F08080; -fx-font-size: 1.2em; ");

	}

	// getters

	public Scene getShowRevenueScene() {
		return showRevenueScene;
	}

	public TextArea getCompanysRevenue() {
		return companysRevenue;
	}

	public Button getBackToMenuFromRevenue() {
		return backToMenuFromRevenue;
	}

	public VBox getVbRootShowRevenue() {
		return vbRootShowRevenue;
	}

	public Label getRevenueLabel() {
		return revenueLabel;
	}

	public Label getPositiveRevenue() {
		return positiveRevenue;
	}

	public Label getNegativeRevenue() {
		return negativeRevenue;
	}

	public Label getRevenueIsZero() {
		return revenueIsZero;
	}

}
