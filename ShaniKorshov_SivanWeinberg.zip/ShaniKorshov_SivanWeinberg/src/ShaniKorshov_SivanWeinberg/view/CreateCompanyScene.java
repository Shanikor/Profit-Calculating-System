package ShaniKorshov_SivanWeinberg.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class CreateCompanyScene {
	
	private TextField companyName;
	private TextField averageIncome;
	private Button createCompany;
	private Scene entryScene;

	public CreateCompanyScene() {
		// entry stage - enter company's info

		Label l1 = new Label("Revenue Simulator");
		l1.setFont(Font.font("Segoe UI Black", FontWeight.SEMI_BOLD, FontPosture.REGULAR, 35));

		Label l2 = new Label("Company name:");
		l2.setFont(Font.font("Calibri", FontWeight.BOLD, FontPosture.REGULAR, 18));

		Label l3 = new Label("Average revenue from worker per hour (NIS) :");
		l3.setFont(Font.font("Calibri", FontWeight.BOLD, FontPosture.REGULAR, 18));

		VBox companyInfo = new VBox(l2, l3);
		companyInfo.setSpacing(10);
		companyInfo.setPadding(new Insets(15));

		companyName = new TextField();
		companyName.setPromptText("Microsoft");
	
		averageIncome = new TextField();
		averageIncome.setPromptText("256");

		VBox companyInfoAns = new VBox(companyName, averageIncome);
		companyInfoAns.setSpacing(10);
		companyInfoAns.setAlignment(Pos.CENTER);

		HBox companyInfoField = new HBox(companyInfo, companyInfoAns);
		companyInfoField.setPadding(new Insets(15));
		companyInfoField.setSpacing(10);
		
		createCompany = new Button("Enter");
		createCompany.setStyle("-fx-background-color: #98FB98; -fx-font-size: 1.2em; ");

		VBox vbRootCompany = new VBox(l1, companyInfoField, createCompany);
		vbRootCompany.setPadding(new Insets(15));
		vbRootCompany.setSpacing(10);
		vbRootCompany.setAlignment(Pos.CENTER);

		entryScene = new Scene(vbRootCompany, 600, 270);

		vbRootCompany.setBackground(new Background(new BackgroundFill(Color.GHOSTWHITE, null, null)));

	}

	//getters 
	
	public TextField getCompanyName() {
		return companyName;
	}

	public TextField getAverageIncome() {
		return averageIncome;
	}

	public Button getCreateCompany() {
		return createCompany;
	}

	public Scene getEntryScene() {
		return entryScene;
	}
	
}
