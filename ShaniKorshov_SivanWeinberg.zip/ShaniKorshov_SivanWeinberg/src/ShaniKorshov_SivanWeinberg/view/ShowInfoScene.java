package ShaniKorshov_SivanWeinberg.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class ShowInfoScene {
	
	private Button backToMainFromInfo;
	private Scene showInfoScene;
	private TextArea allInfo;

	public ShowInfoScene() {
		
		// show company's info scene

		VBox companysInfo = new VBox();
		companysInfo.setPadding(new Insets(15));
		companysInfo.setSpacing(10);
		companysInfo.setAlignment(Pos.CENTER);
		companysInfo.setBackground(new Background(new BackgroundFill(Color.GHOSTWHITE, null, null)));

		Label showInfoLabel = new Label("Company's Info");
		showInfoLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.ITALIC, 40));
		Label emptyLabel = new Label("");

		
		allInfo = new TextArea();
		allInfo.setEditable(false);

		backToMainFromInfo = new Button("Back");
		backToMainFromInfo.setStyle("-fx-background-color: #F08080; -fx-font-size: 1.2em; ");

		companysInfo.getChildren().addAll(showInfoLabel, allInfo,emptyLabel, backToMainFromInfo);
		
		showInfoScene = new Scene(companysInfo, 530, 400);
	}

	//getters 
	
	public Button getBackToMainFromInfo() {
		return backToMainFromInfo;
	}

	public Scene getShowInfoScene() {
		return showInfoScene;
	}

	public TextArea getAllInfo() {
		return allInfo;
	}
	
	
	
	

}
