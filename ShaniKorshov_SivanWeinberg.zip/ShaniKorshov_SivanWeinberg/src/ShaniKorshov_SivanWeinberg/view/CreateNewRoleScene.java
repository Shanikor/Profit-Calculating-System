package ShaniKorshov_SivanWeinberg.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class CreateNewRoleScene {
	
	private Scene createRoleScene;
	private CheckBox roleIsChangable;
	private TextField roleNameAns;
	private ComboBox<String> departmentsNames;
	private Button createRoleButton;
	private Button backToMain;

	public CreateNewRoleScene() {

		// create new role in the company

		VBox vbRootCreateRole = new VBox();
		vbRootCreateRole.setPadding(new Insets(15));
		vbRootCreateRole.setSpacing(10);
		vbRootCreateRole.setAlignment(Pos.CENTER);
		vbRootCreateRole.setBackground(new Background(new BackgroundFill(Color.GHOSTWHITE, null, null)));

		createRoleScene = new Scene(vbRootCreateRole, 500, 300);

		Label createRoleLabel = new Label("Create role");
		createRoleLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.ITALIC, 40));

		roleIsChangable = new CheckBox("Role's working hours are changeable");
		roleIsChangable.setStyle("-fx-font-size: 1.2em; ");

		Label roleName = new Label("Role name: ");
		roleName.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));
		
		roleNameAns = new TextField();
		roleNameAns.setPromptText("Developer");

		Label rolesDep = new Label("Role's department: ");
		rolesDep.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));

		// left
		VBox vbRootCreateRoleLabels = new VBox(roleName, rolesDep);
		vbRootCreateRoleLabels.setPadding(new Insets(15));
		vbRootCreateRoleLabels.setSpacing(10);
		vbRootCreateRoleLabels.setAlignment(Pos.CENTER_LEFT);

		departmentsNames = new ComboBox<String>();

		// right
		VBox vbRootCreateRoleAns = new VBox(roleNameAns, departmentsNames);
		vbRootCreateRoleAns.setPadding(new Insets(15));
		vbRootCreateRoleAns.setSpacing(10);
		vbRootCreateRoleAns.setAlignment(Pos.CENTER_LEFT);

		HBox hbRootCreateRole = new HBox();
		vbRootCreateRole.setPadding(new Insets(15));
		vbRootCreateRole.setSpacing(10);
		vbRootCreateRole.setAlignment(Pos.CENTER);

		HBox backAndCreateButtons = new HBox();
		backAndCreateButtons.setPadding(new Insets(15));
		backAndCreateButtons.setSpacing(10);
		backAndCreateButtons.setAlignment(Pos.CENTER);

		createRoleButton = new Button("Create");
		createRoleButton.setStyle("-fx-background-color: #98FB98; -fx-font-size: 1.2em; ");
		
		backToMain = new Button("Back");
		backToMain.setStyle("-fx-background-color: #F08080; -fx-font-size: 1.2em; ");

		backAndCreateButtons.getChildren().addAll(createRoleButton, backToMain);

		hbRootCreateRole.getChildren().addAll(vbRootCreateRoleLabels, vbRootCreateRoleAns);

		vbRootCreateRole.getChildren().addAll(createRoleLabel, hbRootCreateRole, roleIsChangable, backAndCreateButtons);

	}

	//getters 

	public Scene getCreateRoleScene() {
		return createRoleScene;
	}

	public CheckBox getRoleIsChangable() {
		return roleIsChangable;
	}

	public TextField getRoleNameAns() {
		return roleNameAns;
	}

	public ComboBox<String> getDepartmentsNames() {
		return departmentsNames;
	}

	public Button getCreateRoleButton() {
		return createRoleButton;
	}

	public Button getBackToMain() {
		return backToMain;
	}
		
	

}
