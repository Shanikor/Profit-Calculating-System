package ShaniKorshov_SivanWeinberg.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class ChangeWorkingMethodByRoleScene {

	private Scene changeByRoleScene;
	private ComboBox<String> departmentNamesForChange2CB;
	private ComboBox<String> rolesNamesCB;
	private CheckBox chooseWorkFromHome2;
	private ComboBox<String> workingHours2;
	private Button changeByRole;
	private Button backToMenuFromChangeRole;
	private HBox hbStartHour2;

	public ChangeWorkingMethodByRoleScene() {

		// change working method by role scene

		VBox vbRootChangeByRole = new VBox();
		vbRootChangeByRole.setPadding(new Insets(15));
		vbRootChangeByRole.setSpacing(10);
		vbRootChangeByRole.setAlignment(Pos.CENTER);
		vbRootChangeByRole.setBackground(new Background(new BackgroundFill(Color.GHOSTWHITE, null, null)));

		changeByRoleScene = new Scene(vbRootChangeByRole, 580, 400);

		Label changeByRoleLabel = new Label("Change working method for a role");
		changeByRoleLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.ITALIC, 30));

		Label departmentNameForChange2 = new Label("Department: ");
		departmentNameForChange2.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));

		departmentNamesForChange2CB = new ComboBox<String>();

		HBox hbChooseDep2 = new HBox(departmentNameForChange2, departmentNamesForChange2CB);
		hbChooseDep2.setPadding(new Insets(15));
		hbChooseDep2.setSpacing(10);
		hbChooseDep2.setAlignment(Pos.CENTER);

		Label roleNameForChange = new Label("Role:");
		roleNameForChange.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));

		rolesNamesCB = new ComboBox<String>();

		HBox hbChooseRole = new HBox(roleNameForChange, rolesNamesCB);
		hbChooseRole.setPadding(new Insets(15));
		hbChooseRole.setSpacing(10);
		hbChooseRole.setAlignment(Pos.CENTER);

		chooseWorkFromHome2 = new CheckBox("Work from home");

		Label startHourLabel2 = new Label("Start hour: ");
		startHourLabel2.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));

		workingHours2 = new ComboBox<String>();

		workingHours2.getItems().addAll("00:00", "01:00", "02:00", "03:00", "04:00", "05:00", "06:00", "07:00", "08:00",
				"09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00",
				"20:00", "21:00", "22:00", "23:00");

		hbStartHour2 = new HBox();
		hbStartHour2.setPadding(new Insets(15));
		hbStartHour2.setSpacing(10);
		hbStartHour2.setAlignment(Pos.CENTER);
		hbStartHour2.getChildren().addAll(startHourLabel2, workingHours2);

		// change and back buttons HB

		changeByRole = new Button("Change");
		changeByRole.setStyle("-fx-background-color: #98FB98; -fx-font-size: 1.2em; ");

		backToMenuFromChangeRole = new Button("Back");
		backToMenuFromChangeRole.setStyle("-fx-background-color: #F08080; -fx-font-size: 1.2em; ");

		HBox hbChangeAndBackFromRole = new HBox(changeByRole, backToMenuFromChangeRole);
		hbChangeAndBackFromRole.setPadding(new Insets(15));
		hbChangeAndBackFromRole.setSpacing(10);
		hbChangeAndBackFromRole.setAlignment(Pos.CENTER);

		vbRootChangeByRole.getChildren().addAll(changeByRoleLabel, hbChooseDep2, hbChooseRole, chooseWorkFromHome2,
				hbStartHour2, hbChangeAndBackFromRole);
	}

	public Scene getChangeByRoleScene() {
		return changeByRoleScene;
	}

	public ComboBox<String> getDepartmentNamesForChange2CB() {
		return departmentNamesForChange2CB;
	}

	public ComboBox<String> getRolesNamesCB() {
		return rolesNamesCB;
	}

	public CheckBox getChooseWorkFromHome2() {
		return chooseWorkFromHome2;
	}

	public ComboBox<String> getWorkingHours2() {
		return workingHours2;
	}

	public Button getChangeByRole() {
		return changeByRole;
	}

	public Button getBackToMenuFromChangeRole() {
		return backToMenuFromChangeRole;
	}

	public HBox getHbStartHour2() {
		return hbStartHour2;
	}

}
