package ShaniKorshov_SivanWeinberg.view;

import java.io.IOException;
import java.util.Vector;
import javax.swing.JOptionPane;
import ShaniKorshov_SivanWeinberg.listeners.ViewListenable;
import ShaniKorshov_SivanWeinberg.model.Department;
import ShaniKorshov_SivanWeinberg.model.departmentAlreadyExistsException;
import ShaniKorshov_SivanWeinberg.model.departmentIsntChangeableException;
import ShaniKorshov_SivanWeinberg.model.employeeIsAlreadyExists;
import ShaniKorshov_SivanWeinberg.model.nineDigitsIdException;
import ShaniKorshov_SivanWeinberg.model.notAllRolesAreChangeable;
import ShaniKorshov_SivanWeinberg.model.onlyDigitsIdException;
import ShaniKorshov_SivanWeinberg.model.onlyLettersAllowedException;
import ShaniKorshov_SivanWeinberg.model.percentageException;
import ShaniKorshov_SivanWeinberg.model.positiveNumberException;
import ShaniKorshov_SivanWeinberg.model.roleIsAlreadyExists;
import ShaniKorshov_SivanWeinberg.model.roleIsNotChangeable;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;

public class View {
	private Vector<ViewListenable> allListeners = new Vector<ViewListenable>();
	boolean controlerWasCreated = false;
	private LoadFromFileScene loadFromFileScene;
	private CreateCompanyScene createCompanyScene;
	private MenuScene menuScene;
	private CreateNewDepartmentScene createNewDepartmentScene;
	private ShowInfoScene showInfoScene;
	private CreateNewRoleScene createNewRoleScene;
	private CreateNewEmployeeScene createNewEmployeeScene;
	private ChangeWorkingMethodByDepScene changeWorkingMethodByDepScene;
	private ChangeWorkingMethodByRoleScene changeWorkingMethodByRoleScene;
	private ShowRevenueScene showRevenueScene;

	public View(Stage primaryStage) throws ClassNotFoundException, IOException {
		loadFromFileScene = new LoadFromFileScene();
		createCompanyScene = new CreateCompanyScene();
		menuScene = new MenuScene();
		createNewDepartmentScene = new CreateNewDepartmentScene();
		showInfoScene = new ShowInfoScene();
		createNewRoleScene = new CreateNewRoleScene();
		createNewEmployeeScene = new CreateNewEmployeeScene();
		changeWorkingMethodByDepScene = new ChangeWorkingMethodByDepScene();
		changeWorkingMethodByRoleScene = new ChangeWorkingMethodByRoleScene();
		showRevenueScene = new ShowRevenueScene();
		primaryStage.setResizable(false);
		primaryStage.setTitle("Revenue Simulator");
		primaryStage.show();
		primaryStage.setScene(loadFromFileScene.getLoadFromFileScene());

		// set on actions
		// if user wants to load data from a file - try to load, and show menu
		loadFromFileScene.getYesButton().setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent arg0) {
				try {
					fireLoadfromFile();
					primaryStage.setScene(menuScene.getMenuScene());
					showMsg("Latest data was loaded successfully from file");
				} catch (ClassNotFoundException e) {
					showMsg(e.getMessage());
					primaryStage.setScene(createCompanyScene.getEntryScene());
				} catch (IOException e) {
					showMsg("File doesn't exist!\nPlease enter company's info.");
					primaryStage.setScene(createCompanyScene.getEntryScene());
				}
			}
		});
		// if user doesn't want to load data from file - create new company
		loadFromFileScene.getNoButton().setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent arg0) {
				primaryStage.setScene(createCompanyScene.getEntryScene());
			}
		});
		// create company button
		createCompanyScene.getCreateCompany().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				double revenuePerWorker = 0;
				boolean infoIsOk = true;
				if ((createCompanyScene.getCompanyName().getText().isBlank())
						|| (createCompanyScene.getAverageIncome().getText().isBlank())) {
					infoIsOk = false;
					showMsg("Important information is missing!");
				} else {
					String companyName1 = createCompanyScene.getCompanyName().getText(); // any name is acceptable
					try {
						revenuePerWorker = Double.parseDouble(createCompanyScene.getAverageIncome().getText());
					} catch (IllegalArgumentException e) {
						infoIsOk = false;
						showMsg("Invalid input!\nRevenue value must contain only numbers.");
					} catch (Exception e) {
						infoIsOk = false;
						showMsg(e.getMessage());
					}
					if (infoIsOk) {
						fireSendCompanyToModel(companyName1, revenuePerWorker);
						primaryStage.setScene(menuScene.getMenuScene());
					}
				}
			}
		});
		// create department button - Menu
		menuScene.getCreateDepartment().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				primaryStage.setScene(createNewDepartmentScene.getCreateDepartmentScene());
			}
		});
		// "Create" button - in create **department** scene
		createNewDepartmentScene.getCreateDepartmentButton().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				if (createNewDepartmentScene.getDepartmentNameAns().getText().isBlank())
					showMsg("Important information is missing!");
				else {
					String depName = createNewDepartmentScene.getDepartmentNameAns().getText();
					boolean isChangeableAns = createNewDepartmentScene.getIsChangable().isSelected();
					boolean isSynchronizableAns = createNewDepartmentScene.getIsSynchronizable().isSelected();
					try {
						fireSendDepartment(depName, isChangeableAns, isSynchronizableAns);
						showMsg("Department was created successfully!");
					} catch (departmentAlreadyExistsException e) {
						showMsg(e.getMessage());
					}
					createNewDepartmentScene.getDepartmentNameAns().clear();
					createNewDepartmentScene.getIsChangable().setSelected(false);
					createNewDepartmentScene.getIsSynchronizable().setSelected(false);
					primaryStage.setScene(menuScene.getMenuScene());
				}
			}
		});
		// create new role button - Menu
		menuScene.getCreateRole().setOnAction(new EventHandler<ActionEvent>() {
			Vector<Department> departments = new Vector<Department>();

			@Override
			public void handle(ActionEvent button) {
				createNewRoleScene.getDepartmentsNames().getItems().clear();
				departments = fireGetDepartmentList();
				if (departments.isEmpty()) {
					showMsg("Can't create role, create at least one department first!");
				} else {
					for (int i = 0; i < departments.size(); i++) {
						createNewRoleScene.getDepartmentsNames().getItems().add(departments.get(i).getName());
					}
					primaryStage.setScene(createNewRoleScene.getCreateRoleScene());
				}
			}
		});
		// 'Create' button - in create new role scene
		createNewRoleScene.getCreateRoleButton().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				if (createNewRoleScene.getRoleNameAns().getText().isBlank()
						|| (createNewRoleScene.getDepartmentsNames().getValue() == null)) {
					showMsg("Important information is missing!");
				} else {
					try {
						fireSendRoleToModel(createNewRoleScene.getRoleNameAns().getText(),
								createNewRoleScene.getRoleIsChangable().isSelected(),
								createNewRoleScene.getDepartmentsNames().getValue());
						showMsg("Role was created successfully!");
						createNewRoleScene.getRoleNameAns().clear();
						createNewRoleScene.getRoleIsChangable().setSelected(false);
						primaryStage.setScene(menuScene.getMenuScene());
					} catch (onlyLettersAllowedException e) {
						showMsg(e.getMessage());
					} catch (roleIsAlreadyExists e) {
						showMsg(e.getMessage());
					}
				}
			}
		});
		// create employee - menu
		menuScene.getCreateEmployee().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				createNewEmployeeScene.getEmployeesNameAns().clear();
				createNewEmployeeScene.getEmployeesIdAns().clear();
				createNewEmployeeScene.getDepartmentsNames2().getItems().clear();
				createNewEmployeeScene.getRolesNames().getItems().clear();
				createNewEmployeeScene.getPreferences().getSelectionModel().clearSelection();
				createNewEmployeeScene.getMonthlySalaryAns().clear();
				createNewEmployeeScene.getPerHourSalaryAns().clear();
				createNewEmployeeScene.getPercentageOfSalesAns().clear();
				createNewEmployeeScene.getBaseMonthlySalary().setSelected(false);
				createNewEmployeeScene.getBasePlusSales().setSelected(false);
				createNewEmployeeScene.getPerHourSalary().setSelected(false);
				createNewEmployeeScene.getSalesRevenueAns().clear();
				Vector<Department> departments2 = new Vector<Department>();
				departments2 = fireGetDepartmentList();

				if (departments2.isEmpty() || !(fireCheckCanCreateEmployee())) {
					showMsg("Can't create Employee, create at least one role first!");
				} else {
					for (int i = 0; i < departments2.size(); i++) {
						createNewEmployeeScene.getDepartmentsNames2().getItems().add(departments2.get(i).getName());
					}
					primaryStage.setScene(createNewEmployeeScene.getCreateEmployeeScene());
				}
			}
		});
		// 'Create' button in create new employee scene
		createNewEmployeeScene.getCreateEmployeeButton().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				int salary = 0;
				int percentage = 0;
				int revenue = 0;
				boolean infoIsOk = true;

				String name = createNewEmployeeScene.getEmployeesNameAns().getText();
				String id = createNewEmployeeScene.getEmployeesIdAns().getText();
				String depName = createNewEmployeeScene.getDepartmentsNames2().getValue();
				String roleName = createNewEmployeeScene.getRolesNames().getValue();
				int preference = createNewEmployeeScene.getPreferences().getSelectionModel().getSelectedIndex();
				boolean salaryTypeSelected = (createNewEmployeeScene.getBaseMonthlySalary().isSelected()
						|| createNewEmployeeScene.getPerHourSalary().isSelected()
						|| createNewEmployeeScene.getBasePlusSales().isSelected());
				if (name.isBlank() || id.isBlank() || depName == null || roleName == null
						|| createNewEmployeeScene.getPreferences().getValue() == null || !salaryTypeSelected) {
					showMsg("Important information is missing!");
				}
				// try to create base monthly salary employee
				else if (createNewEmployeeScene.getBaseMonthlySalary().isSelected()) {
					if (createNewEmployeeScene.getMonthlySalaryAns().getText().isBlank())
						showMsg("Salary is missing!");
					else {
						try {
							salary = Integer.parseInt(createNewEmployeeScene.getMonthlySalaryAns().getText());
						} catch (IllegalArgumentException e) {
							infoIsOk = false;
							showMsg("Invalid input!\nSalary must contain only numbers.");
						} catch (Exception e) {
							infoIsOk = false;
							showMsg(e.getMessage());
						}
						if (infoIsOk) {
							try {
								fireSendEmployeeToModel(name, id, 0, depName, roleName, preference, percentage, salary,
										revenue);

								showMsg("Employee was created successfully!");
								primaryStage.setScene(menuScene.getMenuScene());
							} catch (onlyLettersAllowedException e) {
								showMsg(e.getMessage());
							} catch (positiveNumberException e) {
								showMsg(e.getMessage());
							} catch (nineDigitsIdException e) {
								showMsg(e.getMessage());
							} catch (onlyDigitsIdException e) {
								showMsg(e.getMessage());
							} catch (percentageException e) {
								showMsg(e.getMessage());
							} catch (employeeIsAlreadyExists e) {
								showMsg(e.getMessage());
							}
						}
					}
					// try to create per hour salary employee
				} else if (createNewEmployeeScene.getPerHourSalary().isSelected()) {
					if (createNewEmployeeScene.getPerHourSalaryAns().getText().isBlank())
						showMsg("Salary is missing!");
					else {
						try {
							salary = Integer.parseInt(createNewEmployeeScene.getPerHourSalaryAns().getText());
						} catch (IllegalArgumentException e) {
							showMsg("Invalid input!\nSalary must contain only numbers.");
							infoIsOk = false;
						} catch (Exception e) {
							infoIsOk = false;
							showMsg(e.getMessage());
						}
						if (infoIsOk) {
							try {
								fireSendEmployeeToModel(name, id, 1, depName, roleName, preference, percentage, salary,
										revenue);
								showMsg("Employee was created successfully!");

								primaryStage.setScene(menuScene.getMenuScene());
							} catch (onlyLettersAllowedException e) {
								showMsg(e.getMessage());
							} catch (positiveNumberException e) {
								showMsg(e.getMessage());
							} catch (nineDigitsIdException e) {
								showMsg(e.getMessage());
							} catch (onlyDigitsIdException e) {
								showMsg(e.getMessage());
							} catch (percentageException e) {
								showMsg(e.getMessage());
							} catch (employeeIsAlreadyExists e) {
								showMsg(e.getMessage());
							}
						}
					}
					// try to create base monthly plus bonus salary employee
				} else if (createNewEmployeeScene.getBasePlusSales().isSelected()) {
					if (createNewEmployeeScene.getMonthlySalaryAns().getText().isBlank())
						showMsg("Salary is missing!");
					else if (createNewEmployeeScene.getPercentageOfSalesAns().getText().isBlank())
						showMsg("Percentage of sales is missing!");
					else if (createNewEmployeeScene.getSalesRevenueAns().getText().isBlank())
						showMsg("Total revenue of sales is missing!");
					else {
						try {
							salary = Integer.parseInt(createNewEmployeeScene.getMonthlySalaryAns().getText());
							percentage = Integer.parseInt(createNewEmployeeScene.getPercentageOfSalesAns().getText());
							revenue = Integer.parseInt(createNewEmployeeScene.getSalesRevenueAns().getText());
						} catch (IllegalArgumentException e) {
							showMsg("Invalid input! enter only numbers");
							infoIsOk = false;
						} catch (Exception e) {
							infoIsOk = false;
							showMsg(e.getMessage());
						}
						if (infoIsOk) {
							try {
								fireSendEmployeeToModel(name, id, 2, depName, roleName, preference, percentage, salary,
										revenue);
								showMsg("Employee was created successfully!");
								primaryStage.setScene(menuScene.getMenuScene());
							} catch (onlyLettersAllowedException e) {
								showMsg(e.getMessage());
							} catch (positiveNumberException e) {
								showMsg(e.getMessage());
							} catch (nineDigitsIdException e) {
								showMsg(e.getMessage());
							} catch (onlyDigitsIdException e) {
								showMsg(e.getMessage());
							} catch (percentageException e) {
								showMsg(e.getMessage());
							} catch (employeeIsAlreadyExists e) {
								showMsg(e.getMessage());
							}
						}
					}
				}
			}
		});
		// when department is selected for choosing a role - update roles list
		createNewEmployeeScene.getDepartmentsNames2().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				createNewEmployeeScene.getRolesNames().getItems().clear();
				Vector<Department> departments3 = new Vector<Department>();
				departments3 = fireGetDepartmentList();
				int depIndex = createNewEmployeeScene.getDepartmentsNames2().getSelectionModel().getSelectedIndex();
				if (depIndex != -1) {
					for (int i = 0; i < departments3.get(depIndex).getRoles().size(); i++) {
						createNewEmployeeScene.getRolesNames().getItems()
								.add(departments3.get(depIndex).getRoles().get(i).getName());
					}
				}
			}
		});
		// user chooses radio button - base salary option
		createNewEmployeeScene.getBaseMonthlySalary().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				createNewEmployeeScene.getMonthlyPlusBonusFields().setVisible(false);
				createNewEmployeeScene.getSalaryDetails().getChildren().clear();
				createNewEmployeeScene.getSalaryDetails().getChildren().addAll(
						createNewEmployeeScene.getMonthlySalary(), createNewEmployeeScene.getMonthlySalaryAns());
			}
		});
		// user chooses radio button - per hour salary option
		createNewEmployeeScene.getPerHourSalary().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				createNewEmployeeScene.getMonthlyPlusBonusFields().setVisible(false);
				createNewEmployeeScene.getSalaryDetails().getChildren().clear();
				createNewEmployeeScene.getSalaryDetails().getChildren().addAll(createNewEmployeeScene.getHourSalary(),
						createNewEmployeeScene.getPerHourSalaryAns());
			}
		});
		// user chooses radio button - base salary plus bonus option
		createNewEmployeeScene.getBasePlusSales().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				createNewEmployeeScene.getMonthlyPlusBonusFields().setVisible(true);
				createNewEmployeeScene.getSalaryDetails().getChildren().clear();
				createNewEmployeeScene.getSalaryDetails().getChildren().addAll(
						createNewEmployeeScene.getMonthlySalary(), createNewEmployeeScene.getMonthlySalaryAns());
			}
		});
		// show company's information button
		menuScene.getShowCompanysInfo().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				showInfoScene.getAllInfo().setText(fireGetCompanysInfo());
				primaryStage.setScene(showInfoScene.getShowInfoScene());
			}
		});
		// back to menu from 'Create new role' scene
		createNewRoleScene.getBackToMain().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				primaryStage.setScene(menuScene.getMenuScene());
			}
		});
		// back to menu from 'Show company's info' scene
		showInfoScene.getBackToMainFromInfo().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				primaryStage.setScene(menuScene.getMenuScene());
			}
		});
		// back to menu from 'Create new department' scene
		createNewDepartmentScene.getBackToMainFromDep().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				primaryStage.setScene(menuScene.getMenuScene());
			}
		});
		// back to menu from 'Create new employee' scene
		createNewEmployeeScene.getBackToMainFromEmp().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				primaryStage.setScene(menuScene.getMenuScene());// back to menu
			}
		});
		// back to menu from changing working method for a department scene
		changeWorkingMethodByDepScene.getBackToMenuFromChangeDep().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				primaryStage.setScene(menuScene.getMenuScene());// back to menu
			}
		});
		// back to menu from changing working method for a role scene
		changeWorkingMethodByRoleScene.getBackToMenuFromChangeRole().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				primaryStage.setScene(menuScene.getMenuScene());// back to menu
			}
		});
		// back to menu from changing working method for a role scene
		showRevenueScene.getBackToMenuFromRevenue().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				primaryStage.setScene(menuScene.getMenuScene());// back to menu
			}
		});
		// change department working method - menu
		menuScene.getChangeDepartmentWorkingMethod().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				changeWorkingMethodByDepScene.getDepartmentsNamesForChange().getItems().clear();
				changeWorkingMethodByDepScene.getWorkingHours().setValue(null);
				Vector<Department> departments4 = new Vector<Department>();
				departments4 = fireGetDepartmentList();

				if (departments4.isEmpty()) {
					showMsg("There are no departments in the company!");
				} else {
					for (int i = 0; i < departments4.size(); i++) {
						changeWorkingMethodByDepScene.getDepartmentsNamesForChange().getItems()
								.add(departments4.get(i).getName());
					}
					primaryStage.setScene(changeWorkingMethodByDepScene.getChangeByDepScene());
				}
			}
		});
		// work from home check-box
		changeWorkingMethodByDepScene.getChooseWorkFromHome().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				if (changeWorkingMethodByDepScene.getChooseWorkFromHome().isSelected()) {
					changeWorkingMethodByDepScene.getHbStartHour().setVisible(false);
				} else {
					changeWorkingMethodByDepScene.getHbStartHour().setVisible(true);
				}
			}
		});
		// change button in change working method by department scene
		changeWorkingMethodByDepScene.getChangeByDepartment().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				if (changeWorkingMethodByDepScene.getDepartmentsNamesForChange().getValue() == null)
					showMsg("Select a department please!");
				else {
					if (!(changeWorkingMethodByDepScene.getChooseWorkFromHome().isSelected())
							&& changeWorkingMethodByDepScene.getWorkingHours().getValue() == null)
						showMsg("Select new start hour!");
					// if there is no missing information:
					else {
						String departmentName = changeWorkingMethodByDepScene.getDepartmentsNamesForChange().getValue();
						int startingHour = -1;
						boolean workFromHome = changeWorkingMethodByDepScene.getChooseWorkFromHome().isSelected();

						if (changeWorkingMethodByDepScene.getChooseWorkFromHome().isSelected())
							try {
								fireChangeMethodByDep(departmentName, startingHour, workFromHome);
								showMsg("Working method was changed successfully");
								primaryStage.setScene(menuScene.getMenuScene());
							} catch (departmentIsntChangeableException e) {
								showMsg(e.getMessage());
							} catch (notAllRolesAreChangeable e) {
								showMsg(e.getMessage());
							}
						else {
							startingHour = changeWorkingMethodByDepScene.getWorkingHours().getSelectionModel()
									.getSelectedIndex();
							try {
								fireChangeMethodByDep(departmentName, startingHour, workFromHome);
								showMsg("Working method was changed successfully");
								primaryStage.setScene(menuScene.getMenuScene());
							} catch (departmentIsntChangeableException e) {
								showMsg(e.getMessage());
							} catch (notAllRolesAreChangeable e) {
								showMsg(e.getMessage());
							}
						}
					}
				}
			}
		});
		// change role working method - menu
		menuScene.getChangeRoleWorkingMethod().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				// add all departments names to department ComboBox
				changeWorkingMethodByRoleScene.getDepartmentNamesForChange2CB().getItems().clear();
				changeWorkingMethodByRoleScene.getWorkingHours2().setValue(null);

				Vector<Department> departments5 = new Vector<Department>();
				departments5 = fireGetDepartmentList();

				if (departments5.isEmpty()) {
					showMsg("There are no departments in the company!");
				} else {
					boolean oneRole = false;
					for (int i = 0; i < departments5.size(); i++) {
						if (!(departments5.get(i).getRoles().isEmpty())) {
							oneRole = true;
						}
					}
					if (!oneRole) {
						showMsg("There are no roles in the company!");
					} else {
						for (int i = 0; i < departments5.size(); i++) {
							changeWorkingMethodByRoleScene.getDepartmentNamesForChange2CB().getItems()
									.add(departments5.get(i).getName());
						}
						primaryStage.setScene(changeWorkingMethodByRoleScene.getChangeByRoleScene());
					}
				}
			}
		});
		// when department is selected in changing working method for a role-scene
		// update roles list
		changeWorkingMethodByRoleScene.getDepartmentNamesForChange2CB().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				changeWorkingMethodByRoleScene.getRolesNamesCB().getItems().clear();
				Vector<Department> departments6 = new Vector<Department>();
				departments6 = fireGetDepartmentList();

				int depIndex = changeWorkingMethodByRoleScene.getDepartmentNamesForChange2CB().getSelectionModel()
						.getSelectedIndex();
				if (depIndex != -1) {
					for (int i = 0; i < departments6.get(depIndex).getRoles().size(); i++) {
						changeWorkingMethodByRoleScene.getRolesNamesCB().getItems()
								.add(departments6.get(depIndex).getRoles().get(i).getName());
					}
				}
			}
		});
		// work from home check-box
		changeWorkingMethodByRoleScene.getChooseWorkFromHome2().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				if (changeWorkingMethodByRoleScene.getChooseWorkFromHome2().isSelected()) {
					changeWorkingMethodByRoleScene.getHbStartHour2().setVisible(false);
				} else {
					changeWorkingMethodByRoleScene.getHbStartHour2().setVisible(true);
				}
			}
		});
		// change-button in change working method by role scene
		changeWorkingMethodByRoleScene.getChangeByRole().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				if (changeWorkingMethodByRoleScene.getDepartmentNamesForChange2CB().getValue() == null)
					showMsg("Select a department please!");
				else if (changeWorkingMethodByRoleScene.getRolesNamesCB().getValue() == null)
					showMsg("Select a role please!");
				else {
					if (!(changeWorkingMethodByRoleScene.getChooseWorkFromHome2().isSelected())
							&& changeWorkingMethodByRoleScene.getWorkingHours2().getValue() == null)
						showMsg("Select new start hour!");
					// if there is no missing information:
					else {
						String departmentName2 = changeWorkingMethodByRoleScene.getDepartmentNamesForChange2CB()
								.getValue();
						String roleName2 = changeWorkingMethodByRoleScene.getRolesNamesCB().getValue();
						int startingHour2 = -1;
						boolean workFromHome2 = changeWorkingMethodByRoleScene.getChooseWorkFromHome2().isSelected();

						if (changeWorkingMethodByRoleScene.getChooseWorkFromHome2().isSelected()) {
							try {
								fireChangeMethodByRole(departmentName2, roleName2, startingHour2, workFromHome2);
								showMsg("Working method was changed successfully");
								primaryStage.setScene(menuScene.getMenuScene());
							} catch (departmentIsntChangeableException e) {
								showMsg(e.getMessage());
							} catch (roleIsNotChangeable e) {
								showMsg(e.getMessage());
							} catch (notAllRolesAreChangeable e) {
								showMsg(e.getMessage());
							}
						} else {
							startingHour2 = changeWorkingMethodByRoleScene.getWorkingHours2().getSelectionModel()
									.getSelectedIndex();
							try {
								fireChangeMethodByRole(departmentName2, roleName2, startingHour2, workFromHome2);
								showMsg("Working method was changed successfully");
								primaryStage.setScene(menuScene.getMenuScene());
							} catch (departmentIsntChangeableException e) {
								showMsg(e.getMessage());
							} catch (roleIsNotChangeable e) {
								showMsg(e.getMessage());
							} catch (notAllRolesAreChangeable e) {
								showMsg(e.getMessage());
							}
						}
					}
				}
			}
		});
		// show company's revenue -menu
		menuScene.getShowRevenue().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				Vector<Department> departmentsList = new Vector<Department>();
				departmentsList = fireGetDepartmentList();
				if (departmentsList.isEmpty()) {
					showMsg("Can't calcultate revenue, \nThere are no departments in the company!");
				} else {
					boolean oneRole = false;
					boolean oneEmployee = false;
					for (int i = 0; i < departmentsList.size(); i++) {
						if (!(departmentsList.get(i).getRoles().isEmpty())) {
							oneRole = true;
						}
						for (int j = 0; j < departmentsList.get(i).getRoles().size(); j++) {
							if (!(departmentsList.get(i).getRoles().get(j).getEmployees().isEmpty())) {
								oneEmployee = true;
								break;
							}
						}
					}
					if (!oneRole)
						showMsg("Can't calcultate revenue,\nThere are no roles in the company!");
					else if (!oneEmployee)
						showMsg("Can't calcultate revenue,\nThere are no employees in the company!");
					else {
						showRevenueScene.getCompanysRevenue().setText(fireCalculateRevenue());
						//// get revenue from model and insert to TextArea
						double rev = fireGetRevenue();
						showRevenueScene.getVbRootShowRevenue().getChildren().clear();
						if (rev > 0)
							showRevenueScene.getVbRootShowRevenue().getChildren().addAll(
									showRevenueScene.getRevenueLabel(), showRevenueScene.getCompanysRevenue(),
									showRevenueScene.getPositiveRevenue(), showRevenueScene.getBackToMenuFromRevenue());
						else if (rev < 0)
							showRevenueScene.getVbRootShowRevenue().getChildren().addAll(
									showRevenueScene.getRevenueLabel(), showRevenueScene.getCompanysRevenue(),
									showRevenueScene.getNegativeRevenue(), showRevenueScene.getBackToMenuFromRevenue());
						else // revenue is 0
							showRevenueScene.getVbRootShowRevenue().getChildren().addAll(
									showRevenueScene.getRevenueLabel(), showRevenueScene.getCompanysRevenue(),
									showRevenueScene.getRevenueIsZero(), showRevenueScene.getBackToMenuFromRevenue());
						primaryStage.setScene(showRevenueScene.getShowRevenueScene());
					}
				}
			}
		});
		// when EXIT button is pressed, save to binaric file
		menuScene.getExitButton().setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent button) {
				try {
					fireSaveProgramToFile();
				} catch (IOException e) {
					showMsg(e.getMessage());
				}
				primaryStage.close();
			}
		});
	}

	// register listener
	public void registerListener(ViewListenable l) {
		allListeners.add(l);
	}

	// create an employee - send to model
	public boolean fireSendEmployeeToModel(String name, String id, int salaryType, String depName, String roleName,
			int preference, int percentage, int salary, int revenue)
			throws onlyLettersAllowedException, employeeIsAlreadyExists, nineDigitsIdException, onlyDigitsIdException,
			positiveNumberException, percentageException {
		for (ViewListenable l : allListeners) {
			return l.sendEmpToModel(name, id, salaryType, depName, roleName, preference, percentage, salary, revenue);
		}
		return false;
	}

	// check if user can create an employee (at lease one department and one role!)
	public boolean fireCheckCanCreateEmployee() {
		for (ViewListenable l : allListeners) {
			return l.canCreateEmp();
		}
		return false;
	}

	// create a Role - send to model
	public boolean fireSendRoleToModel(String roleName, boolean isSelected, String department)
			throws roleIsAlreadyExists, onlyLettersAllowedException {
		for (ViewListenable l : allListeners) {
			return l.sendRoleToModel(roleName, isSelected, department);
		}
		return false;
	}

	// create the company
	public void fireSendCompanyToModel(String companyName1, double revenuePerWorker) {
		for (ViewListenable l : allListeners)
			l.askModelToCreateCompany(companyName1, revenuePerWorker);
	}

	// show any message on screen
	public void showMsg(String msg) {
		JOptionPane.showMessageDialog(null, msg, "", JOptionPane.WARNING_MESSAGE);
	}

	// create a department - send to model
	public void fireSendDepartment(String depName, boolean isChangeableAns, boolean isSynchronizableAns)
			throws departmentAlreadyExistsException {
		for (ViewListenable l : allListeners) {
			l.askModelToCreateDep(depName, isChangeableAns, isSynchronizableAns);
		}
	}

	public String fireGetCompanysInfo() {
		for (ViewListenable l : allListeners) {
			return l.getCompanysInfo();
		}
		return "";
	}

	public Vector<Department> fireGetDepartmentList() {
		for (ViewListenable l : allListeners) {
			return l.getDepartmentsList();
		}
		return null;
	}

	// change working method for a department
	public boolean fireChangeMethodByDep(String departmentName, int startingHour, boolean workFromHome)
			throws departmentIsntChangeableException, notAllRolesAreChangeable {
		for (ViewListenable l : allListeners) {
			return l.changeMethodByDep(departmentName, startingHour, workFromHome);
		}
		return false;
	}

	// change working method for a role
	public boolean fireChangeMethodByRole(String departmentName2, String roleName2, int startingHour2,
			boolean workFromHome2)
			throws notAllRolesAreChangeable, departmentIsntChangeableException, roleIsNotChangeable {
		for (ViewListenable l : allListeners) {
			return l.changeMethodByRole(departmentName2, roleName2, startingHour2, workFromHome2);
		}
		return false;
	}

	public String fireCalculateRevenue() {
		for (ViewListenable l : allListeners) {
			return l.getRevenueFromModel();
		}
		return null;
	}

	// ask model for company's revenue
	public double fireGetRevenue() {
		for (ViewListenable l : allListeners) {
			return l.askModelForCompanysRevenue();
		}
		return 0;
	}

	// ask model to save program to file
	public void fireSaveProgramToFile() throws IOException {
		for (ViewListenable l : allListeners) {
			l.askModelToSaveProgramToFile();
		}
	}

	// ask model to load data from existing file
	public void fireLoadfromFile() throws ClassNotFoundException, IOException {
		for (ViewListenable l : allListeners) {
			l.askModelToLoadFromFile();
		}
	}
}