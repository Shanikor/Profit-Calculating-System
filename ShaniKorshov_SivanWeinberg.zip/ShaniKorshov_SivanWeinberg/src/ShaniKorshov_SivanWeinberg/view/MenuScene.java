package ShaniKorshov_SivanWeinberg.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class MenuScene {
	
	private Scene menuScene;
	private Button createDepartment;
	private Button createRole;
	private Button createEmployee;
	private Button showCompanysInfo;
	private Button changeRoleWorkingMethod;
	private Button changeDepartmentWorkingMethod;
	private Button showRevenue;
	private Button exitButton;

	public MenuScene() {
		// menu scene
		VBox vbRootMenu = new VBox();
		vbRootMenu.setPadding(new Insets(10));
		vbRootMenu.setSpacing(10);
		vbRootMenu.setAlignment(Pos.CENTER);
		vbRootMenu.setBackground(new Background(new BackgroundFill(Color.GHOSTWHITE, null, null)));

		menuScene = new Scene(vbRootMenu, 500, 600);

		Label menuLabel = new Label("Revenue calculator");
		menuLabel.setFont(Font.font("Segoe UI Black", FontWeight.BOLD, FontPosture.REGULAR, 40));

		Label createLabel = new Label("Create new:");
		createLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 25));

		createDepartment = new Button("Department");
		createDepartment.setStyle("-fx-font-size: 1.2em; ");

		createRole = new Button("Role");
		createRole.setStyle("-fx-font-size: 1.2em; ");

		createEmployee = new Button("Employee");
		createEmployee.setStyle("-fx-font-size: 1.2em; ");

		HBox createHB = new HBox();
		createHB.setPadding(new Insets(15));
		createHB.setSpacing(10);
		createHB.setAlignment(Pos.CENTER);
		createHB.getChildren().addAll(createDepartment, createRole, createEmployee);

		showCompanysInfo = new Button("Show company's info");
		showCompanysInfo.setStyle("-fx-font-size: 1.3em; ");

		Label changeLabel = new Label("Change working method:");
		changeLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 25));

		changeRoleWorkingMethod = new Button("By role");
		changeRoleWorkingMethod.setStyle("-fx-font-size: 1.3em; ");

		changeDepartmentWorkingMethod = new Button("By department");
		changeDepartmentWorkingMethod.setStyle("-fx-font-size: 1.3em; ");

		HBox changeHB = new HBox();
		changeHB.setPadding(new Insets(15));
		changeHB.setSpacing(10);
		changeHB.setAlignment(Pos.CENTER);
		changeHB.getChildren().addAll(changeRoleWorkingMethod, changeDepartmentWorkingMethod);

		Label MoreLabel = new Label("More: ");
		MoreLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 25));

		showRevenue = new Button("Calculate revenue");
		showRevenue.setStyle("-fx-font-size: 1.3em; ");

		Label blankLable = new Label("");

		exitButton = new Button("EXIT");
		exitButton.setStyle("-fx-background-color: #F08080; -fx-font-size: 1.2em; ");

		vbRootMenu.getChildren().addAll(menuLabel, createLabel, createHB, changeLabel, changeHB, MoreLabel,
				showCompanysInfo, showRevenue, blankLable, exitButton);
	
	}
	
	//getters 
	
	public Scene getMenuScene() {
		return menuScene;
	}
	
	public Button getCreateRole() {
		return createRole;
	}

	public Button getCreateEmployee() {
		return createEmployee;
	}

	public Button getShowCompanysInfo() {
		return showCompanysInfo;
	}

	public Button getChangeRoleWorkingMethod() {
		return changeRoleWorkingMethod;
	}

	public Button getChangeDepartmentWorkingMethod() {
		return changeDepartmentWorkingMethod;
	}

	public Button getShowRevenue() {
		return showRevenue;
	}

	public Button getExitButton() {
		return exitButton;
	}

	public Button getCreateDepartment() {
		return createDepartment;
	}

}
