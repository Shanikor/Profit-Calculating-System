package ShaniKorshov_SivanWeinberg.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class ChangeWorkingMethodByDepScene {
	
	private Scene changeByDepScene;
	private ComboBox<String> departmentsNamesForChange;
	private CheckBox chooseWorkFromHome;
	private ComboBox<String> workingHours;
	private Button changeByDepartment;
	private Button backToMenuFromChangeDep;
	private HBox hbStartHour;

	public ChangeWorkingMethodByDepScene() {

		// change working method by department scene

		VBox vbRootChangeByDep = new VBox();
		vbRootChangeByDep.setPadding(new Insets(15));
		vbRootChangeByDep.setSpacing(10);
		vbRootChangeByDep.setAlignment(Pos.CENTER);
		vbRootChangeByDep.setBackground(new Background(new BackgroundFill(Color.GHOSTWHITE, null, null)));

		changeByDepScene = new Scene(vbRootChangeByDep, 570, 300);

		Label changeByDepLabel = new Label("Change working method for a department");
		changeByDepLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.ITALIC, 30));

		Label departmentNameForChange = new Label("Department: ");
		departmentNameForChange.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));

		departmentsNamesForChange = new ComboBox<String>();

		HBox hbChooseDep = new HBox(departmentNameForChange, departmentsNamesForChange);
		hbChooseDep.setPadding(new Insets(15));
		hbChooseDep.setSpacing(10);
		hbChooseDep.setAlignment(Pos.CENTER);

		chooseWorkFromHome = new CheckBox("Work from home");

		Label startHourLabel = new Label("Start hour: ");
		startHourLabel.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));

		workingHours = new ComboBox<String>();

		workingHours.getItems().addAll("00:00", "01:00", "02:00", "03:00", "04:00", "05:00", "06:00", "07:00", "08:00",
				"09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00",
				"20:00", "21:00", "22:00", "23:00");

		hbStartHour = new HBox();
		hbStartHour.setPadding(new Insets(15));
		hbStartHour.setSpacing(10);
		hbStartHour.setAlignment(Pos.CENTER);
		hbStartHour.getChildren().addAll(startHourLabel, workingHours);

		// change and back buttons HB

		changeByDepartment = new Button("Change");
		changeByDepartment.setStyle("-fx-background-color: #98FB98; -fx-font-size: 1.2em; ");

		backToMenuFromChangeDep = new Button("Back");
		backToMenuFromChangeDep.setStyle("-fx-background-color: #F08080; -fx-font-size: 1.2em; ");

		HBox hbChangeAndBackFromDep = new HBox(changeByDepartment, backToMenuFromChangeDep);
		hbChangeAndBackFromDep.setPadding(new Insets(15));
		hbChangeAndBackFromDep.setSpacing(10);
		hbChangeAndBackFromDep.setAlignment(Pos.CENTER);

		vbRootChangeByDep.getChildren().addAll(changeByDepLabel, hbChooseDep, chooseWorkFromHome, hbStartHour,
				hbChangeAndBackFromDep);

	}

	public Scene getChangeByDepScene() {
		return changeByDepScene;
	}

	public ComboBox<String> getDepartmentsNamesForChange() {
		return departmentsNamesForChange;
	}

	public CheckBox getChooseWorkFromHome() {
		return chooseWorkFromHome;
	}

	public ComboBox<String> getWorkingHours() {
		return workingHours;
	}

	public Button getChangeByDepartment() {
		return changeByDepartment;
	}

	public Button getBackToMenuFromChangeDep() {
		return backToMenuFromChangeDep;
	}

	public HBox getHbStartHour() {
		return hbStartHour;
	}
	
	
	

}
