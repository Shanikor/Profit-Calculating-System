package ShaniKorshov_SivanWeinberg.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class LoadFromFileScene {

	private Button yesButton;
	private Button noButton;
	private Scene loadFromFileScene;

	public LoadFromFileScene() {
		// load from file scene

		Label loadFileLabel = new Label("Do you want to load data from existing file?");
		loadFileLabel.setFont(Font.font("Calibri", FontWeight.BOLD, FontPosture.REGULAR, 18));

		VBox vbLoadFile = new VBox();
		vbLoadFile.setSpacing(10);
		vbLoadFile.setPadding(new Insets(15));
		vbLoadFile.setAlignment(Pos.CENTER);

		yesButton = new Button("Yes");
		yesButton.setStyle("-fx-background-color: #98FB98; -fx-font-size: 1.2em; ");

		noButton = new Button("No");
		noButton.setStyle("-fx-background-color: #F08080; -fx-font-size: 1.2em; ");

		HBox hbLoadFileButtons = new HBox();
		hbLoadFileButtons.setSpacing(10);
		hbLoadFileButtons.setPadding(new Insets(15));
		hbLoadFileButtons.getChildren().addAll(yesButton, noButton);
		hbLoadFileButtons.setAlignment(Pos.CENTER);

		vbLoadFile.getChildren().addAll(loadFileLabel, hbLoadFileButtons);

		loadFromFileScene = new Scene(vbLoadFile, 400, 150);
		vbLoadFile.setBackground(new Background(new BackgroundFill(Color.GHOSTWHITE, null, null)));

	}

	public Button getYesButton() {
		return yesButton;
	}

	public Button getNoButton() {
		return noButton;
	}

	public Scene getLoadFromFileScene() {
		return loadFromFileScene;
	}
	
	

}
