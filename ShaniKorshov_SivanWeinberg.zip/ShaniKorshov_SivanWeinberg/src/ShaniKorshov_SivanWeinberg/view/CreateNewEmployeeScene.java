package ShaniKorshov_SivanWeinberg.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class CreateNewEmployeeScene {

	private Scene createEmployeeScene;
	private TextField employeesNameAns;
	private TextField employeesIdAns;
	private ComboBox<String> departmentsNames2;
	private ComboBox<String> rolesNames;
	private ComboBox<String> preferences;
	private ToggleGroup salaryTypes;
	private RadioButton baseMonthlySalary;
	private RadioButton perHourSalary;
	private RadioButton basePlusSales;
	private TextField monthlySalaryAns;
	private TextField perHourSalaryAns ;
	private TextField percentageOfSalesAns;
	private TextField salesRevenueAns;
	private Button createEmployeeButton;
	private Button backToMainFromEmp;
	private HBox monthlyPlusBonusFields;
	private HBox salaryDetails;
	private Label monthlySalary;
	private Label hourSalary;

	public CreateNewEmployeeScene() {

		// create employee scene

		VBox vbRootCreateEmployee = new VBox();
		vbRootCreateEmployee.setPadding(new Insets(7));
		vbRootCreateEmployee.setSpacing(10);
		vbRootCreateEmployee.setAlignment(Pos.CENTER);
		vbRootCreateEmployee.setBackground(new Background(new BackgroundFill(Color.GHOSTWHITE, null, null)));

		createEmployeeScene = new Scene(vbRootCreateEmployee, 600, 700);

		Label createEmplyoeeLabel = new Label("Create employee");
		createEmplyoeeLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.ITALIC, 40));

		Label employeesName = new Label("Employee's name: ");
		employeesName.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));

		Label employeesId = new Label("Employee's id: ");
		employeesId.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));

		employeesNameAns = new TextField();
		employeesNameAns.setPromptText("Keren Kalif");

		employeesIdAns = new TextField();
		employeesIdAns.setPromptText("123456789");

		Label chooseDepLabel = new Label("Department: ");
		chooseDepLabel.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));

		Label chooseRoleLabel = new Label("Role: ");
		chooseRoleLabel.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));

		departmentsNames2 = new ComboBox<String>();
		rolesNames = new ComboBox<String>();

		Label workingPreferenceLabel = new Label("Working preference:");
		workingPreferenceLabel.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));

		preferences = new ComboBox<String>();
		preferences.getItems().addAll("Start working earlier than 8:00 AM", "Start working later than 8:00 AM",
				"Keep current working hours (8:00-17:00)", "Work from home");

		// left vb - labels
		VBox CreateEmployeeLabels = new VBox();
		CreateEmployeeLabels.setPadding(new Insets(15));
		CreateEmployeeLabels.setSpacing(10);
		CreateEmployeeLabels.setAlignment(Pos.CENTER_LEFT);
		CreateEmployeeLabels.getChildren().addAll(employeesName, employeesId, chooseDepLabel, chooseRoleLabel,
				workingPreferenceLabel);

		// right vb - answers
		VBox CreateEmployeeAns = new VBox();
		CreateEmployeeAns.setPadding(new Insets(15));
		CreateEmployeeAns.setSpacing(10);
		CreateEmployeeAns.setAlignment(Pos.CENTER_RIGHT);
		CreateEmployeeAns.getChildren().addAll(employeesNameAns, employeesIdAns, departmentsNames2, rolesNames,
				preferences);

		// HBox employees details
		HBox empDetails = new HBox();
		empDetails.setPadding(new Insets(15));
		empDetails.setSpacing(10);
		empDetails.setAlignment(Pos.CENTER);
		empDetails.getChildren().addAll(CreateEmployeeLabels, CreateEmployeeAns);

		Label salaryCalculationLabel = new Label("Salary type: ");
		salaryCalculationLabel.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));

		salaryTypes = new ToggleGroup();
		baseMonthlySalary = new RadioButton("Monthly base ");// 0
		perHourSalary = new RadioButton("Per hour ");// 1
		basePlusSales = new RadioButton("Monthly base + sales bonus");// 2

		baseMonthlySalary.setToggleGroup(salaryTypes);
		perHourSalary.setToggleGroup(salaryTypes);
		basePlusSales.setToggleGroup(salaryTypes);

		// radio buttons VB - salary method
		VBox salaryTypesVB = new VBox();
		salaryTypesVB.setPadding(new Insets(5));
		salaryTypesVB.setSpacing(4);
		salaryTypesVB.setAlignment(Pos.CENTER);

		salaryTypesVB.getChildren().addAll(baseMonthlySalary, perHourSalary, basePlusSales);

		// changes depending on user choice of payment method
		VBox MoreDetailsByMethod = new VBox();
		MoreDetailsByMethod.setPadding(new Insets(15));
		MoreDetailsByMethod.setSpacing(10);
		MoreDetailsByMethod.setAlignment(Pos.CENTER);

		salaryDetails = new HBox();
		salaryDetails.setPadding(new Insets(7));
		salaryDetails.setSpacing(10);
		salaryDetails.setAlignment(Pos.CENTER);

		// monthly salary options
		monthlySalary = new Label("Monthly base (NIS) :                        ");
		monthlySalary.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));

		monthlySalaryAns = new TextField();
		monthlySalaryAns.setPromptText("7000");

		// per hour salary
		hourSalary = new Label("Per hour (NIS) : ");
		hourSalary.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));

		perHourSalaryAns = new TextField();
		perHourSalaryAns.setPromptText("50");

		// monthly plus bonus from sales salary options

		Label percentageOfSalesLabel = new Label("Sales bonus (% of monthly sales) : ");
		percentageOfSalesLabel.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));

		percentageOfSalesAns = new TextField();
		percentageOfSalesAns.setPromptText("12");

		Label salesRevenueLabel = new Label("Monthly sales revenue (NIS) : ");
		salesRevenueLabel.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));

		salesRevenueAns = new TextField();
		salesRevenueAns.setPromptText("15000");

		VBox monthlyPlusBonusLabels = new VBox();
		monthlyPlusBonusLabels.setPadding(new Insets(15));
		monthlyPlusBonusLabels.setSpacing(10);
		monthlyPlusBonusLabels.setAlignment(Pos.CENTER_LEFT);
		monthlyPlusBonusLabels.getChildren().addAll(percentageOfSalesLabel, salesRevenueLabel);

		VBox monthlyPlusBonusAns = new VBox();
		monthlyPlusBonusAns.setPadding(new Insets(15));
		monthlyPlusBonusAns.setSpacing(10);
		monthlyPlusBonusAns.setAlignment(Pos.CENTER_RIGHT);
		monthlyPlusBonusAns.getChildren().addAll(percentageOfSalesAns, salesRevenueAns);

		monthlyPlusBonusFields = new HBox();
		monthlyPlusBonusFields.setPadding(new Insets(7));
		monthlyPlusBonusFields.setSpacing(10);
		monthlyPlusBonusFields.setAlignment(Pos.CENTER);
		monthlyPlusBonusFields.getChildren().addAll(monthlyPlusBonusLabels, monthlyPlusBonusAns);

		monthlyPlusBonusFields.setVisible(false);

		createEmployeeButton = new Button("Create");
		createEmployeeButton.setStyle("-fx-background-color: #98FB98; -fx-font-size: 1.2em; ");

		backToMainFromEmp = new Button("Back");
		backToMainFromEmp.setStyle("-fx-background-color: #F08080; -fx-font-size: 1.2em; ");

		HBox backAndCreateButtons2 = new HBox();
		backAndCreateButtons2.setPadding(new Insets(15));
		backAndCreateButtons2.setSpacing(10);
		backAndCreateButtons2.setAlignment(Pos.CENTER);
		backAndCreateButtons2.getChildren().addAll(createEmployeeButton, backToMainFromEmp);

		vbRootCreateEmployee.getChildren().addAll(createEmplyoeeLabel, empDetails, salaryCalculationLabel,
				salaryTypesVB, salaryDetails, monthlyPlusBonusFields, backAndCreateButtons2);

	}

	// getters

	public Scene getCreateEmployeeScene() {
		return createEmployeeScene;
	}

	public TextField getEmployeesNameAns() {
		return employeesNameAns;
	}

	public TextField getEmployeesIdAns() {
		return employeesIdAns;
	}

	public ComboBox<String> getDepartmentsNames2() {
		return departmentsNames2;
	}

	public ComboBox<String> getRolesNames() {
		return rolesNames;
	}

	public ComboBox<String> getPreferences() {
		return preferences;
	}

	public ToggleGroup getSalaryTypes() {
		return salaryTypes;
	}

	public RadioButton getBaseMonthlySalary() {
		return baseMonthlySalary;
	}

	public RadioButton getPerHourSalary() {
		return perHourSalary;
	}

	public RadioButton getBasePlusSales() {
		return basePlusSales;
	}

	public TextField getMonthlySalaryAns() {
		return monthlySalaryAns;
	}

	public TextField getPerHourSalaryAns() {
		return perHourSalaryAns;
	}

	public TextField getPercentageOfSalesAns() {
		return percentageOfSalesAns;
	}

	public TextField getSalesRevenueAns() {
		return salesRevenueAns;
	}

	public Button getCreateEmployeeButton() {
		return createEmployeeButton;
	}

	public Button getBackToMainFromEmp() {
		return backToMainFromEmp;
	}

	public HBox getMonthlyPlusBonusFields() {
		return monthlyPlusBonusFields;
	}

	public HBox getSalaryDetails() {
		return salaryDetails;
	}

	public Label getMonthlySalary() {
		return monthlySalary;
	}

	public Label getHourSalary() {
		return hourSalary;
	}
	
	
	
	
	
	
	
	

}
