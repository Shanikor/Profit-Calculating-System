package ShaniKorshov_SivanWeinberg.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class CreateNewDepartmentScene {
	
	private Button createDepartmentButton;
	private Button backToMainFromDep;
	private Scene createDepartmentScene;
	private TextField departmentNameAns;
	private CheckBox isChangable;
	private CheckBox isSynchronizable;


	public CreateNewDepartmentScene() {

		// create new department scene

		VBox vbRootCreateDep = new VBox();
		vbRootCreateDep.setPadding(new Insets(15));
		vbRootCreateDep.setSpacing(10);
		vbRootCreateDep.setAlignment(Pos.CENTER);
		vbRootCreateDep.setBackground(new Background(new BackgroundFill(Color.GHOSTWHITE, null, null)));

		createDepartmentScene = new Scene(vbRootCreateDep, 500, 300);

		Label createDepartmentLabel = new Label("Create department");
		createDepartmentLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.ITALIC, 40));

		HBox createDepLabels = new HBox();
		createDepLabels.setPadding(new Insets(15));
		createDepLabels.setSpacing(10);
		createDepLabels.setAlignment(Pos.CENTER);

		Label departmentName = new Label("Department name: ");
		departmentName.setFont(Font.font("Times New Roman", FontWeight.NORMAL, FontPosture.REGULAR, 20));

		isChangable = new CheckBox("Working hours are changeable");
		isChangable.setStyle("-fx-font-size: 1.2em; ");
		isSynchronizable = new CheckBox("Working hours are synchronized");
		isSynchronizable.setStyle("-fx-font-size: 1.2em; ");
		departmentNameAns = new TextField();
		departmentNameAns.setPromptText("R&D");

		createDepartmentButton = new Button("Create");
		createDepartmentButton.setStyle("-fx-background-color: #98FB98; -fx-font-size: 1.2em; ");

		backToMainFromDep = new Button("Back");
		backToMainFromDep.setStyle("-fx-background-color: #F08080; -fx-font-size: 1.2em; ");

		HBox createAndBackDep = new HBox(createDepartmentButton, backToMainFromDep);
		createAndBackDep.setPadding(new Insets(15));
		createAndBackDep.setSpacing(10);
		createAndBackDep.setAlignment(Pos.CENTER);

		VBox checkBoxDep = new VBox();
		checkBoxDep.setPadding(new Insets(15));
		checkBoxDep.setSpacing(10);
		checkBoxDep.setAlignment(Pos.CENTER);
		checkBoxDep.getChildren().addAll(isSynchronizable, isChangable);

		createDepLabels.getChildren().addAll(departmentName, departmentNameAns);
		vbRootCreateDep.getChildren().addAll(createDepartmentLabel, createDepLabels, checkBoxDep, createAndBackDep);

	}

	//getters 
	public Button getCreateDepartmentButton() {
		return createDepartmentButton;
	}
	public Button getBackToMainFromDep() {
		return backToMainFromDep;
	}
	public Scene getCreateDepartmentScene() {
		return createDepartmentScene;
	}

	public TextField getDepartmentNameAns() {
		return departmentNameAns;
	}

	public CheckBox getIsChangable() {
		return isChangable;
	}

	public CheckBox getIsSynchronizable() {
		return isSynchronizable;
	}
	
	
	

}
