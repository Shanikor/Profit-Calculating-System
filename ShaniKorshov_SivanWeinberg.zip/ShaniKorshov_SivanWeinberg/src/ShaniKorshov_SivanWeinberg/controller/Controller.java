package ShaniKorshov_SivanWeinberg.controller;

import java.io.IOException;
import java.util.Vector;

import ShaniKorshov_SivanWeinberg.listeners.ModelListenable;
import ShaniKorshov_SivanWeinberg.listeners.ViewListenable;
import ShaniKorshov_SivanWeinberg.model.CompanyProgram;
import ShaniKorshov_SivanWeinberg.model.Department;
import ShaniKorshov_SivanWeinberg.model.departmentAlreadyExistsException;
import ShaniKorshov_SivanWeinberg.model.departmentIsntChangeableException;
import ShaniKorshov_SivanWeinberg.model.employeeIsAlreadyExists;
import ShaniKorshov_SivanWeinberg.model.nineDigitsIdException;
import ShaniKorshov_SivanWeinberg.model.notAllRolesAreChangeable;
import ShaniKorshov_SivanWeinberg.model.onlyDigitsIdException;
import ShaniKorshov_SivanWeinberg.model.onlyLettersAllowedException;
import ShaniKorshov_SivanWeinberg.model.percentageException;
import ShaniKorshov_SivanWeinberg.model.positiveNumberException;
import ShaniKorshov_SivanWeinberg.model.roleIsAlreadyExists;
import ShaniKorshov_SivanWeinberg.model.roleIsNotChangeable;
import ShaniKorshov_SivanWeinberg.view.View;

public class Controller implements ModelListenable,ViewListenable {
	
	private CompanyProgram theModel;
	private View theView;
	public Controller(CompanyProgram m, View v) {
		theModel = m;
		theView = v;
		
	    theView.registerListener(this);
		theModel.registerListener(this);
	}
	
	@Override
	public void askModelToCreateCompany(String companyName1, double revenuePerWorker) {
		theModel.createCompany(companyName1, revenuePerWorker);
	}

	@Override
	public void askModelToCreateDep(String depName, boolean isChangeableAns, boolean isSynchronizableAns) throws departmentAlreadyExistsException {
		theModel.createDepartment(depName, isChangeableAns, isSynchronizableAns);
	}

	@Override
	public void sentMsgToShowForView(String msg) {
		theView.showMsg(msg);
	}

	@Override
	public String getCompanysInfo() {
		return theModel.getCompanysInfo();
	}

	@Override
	public Vector<Department> getDepartmentsList() {
		return theModel.getDepartments();
	}

	@Override
	public boolean sendRoleToModel(String roleName, boolean isSelected, String department) throws roleIsAlreadyExists, onlyLettersAllowedException {
		return theModel.createRole(roleName, isSelected, department);
	}

	@Override
	public boolean canCreateEmp() {
		return theModel.canCreateEmp();
	}

	@Override
	public boolean sendEmpToModel(String name, String id, int salaryType, String depName, String roleName,
			int preference, int percentage, int salary, int revenue) throws onlyLettersAllowedException, employeeIsAlreadyExists, nineDigitsIdException, onlyDigitsIdException, positiveNumberException, percentageException {
		return theModel.createEmployee(name, id, salaryType, depName, roleName, preference, percentage, salary, revenue);
	}

	@Override
	public boolean changeMethodByDep(String departmentName,int startingHour,boolean workFromHome) throws departmentIsntChangeableException, notAllRolesAreChangeable {
		return theModel.changeHoursByDep(departmentName,startingHour,workFromHome);
	}

	@Override
	public boolean changeMethodByRole(String departmentName2, String roleName2, int startingHour2,
			boolean workFromHome2) throws notAllRolesAreChangeable, departmentIsntChangeableException, roleIsNotChangeable {
		return theModel.changeHoursByRole(departmentName2,roleName2,startingHour2,workFromHome2);
	}

	@Override
	public String getRevenueFromModel() {
		return theModel.calculateCompanyRevenue();
	}

	@Override
	public void askModelToSaveProgramToFile() throws IOException {
		theModel.saveProgramToFile();
		
	}

	@Override
	public void askModelToLoadFromFile() throws ClassNotFoundException, IOException {
		 theModel.loadFile();
	}

	@Override
	public double askModelForCompanysRevenue() {
		return theModel.getCompanysRevenue();
	}
}
