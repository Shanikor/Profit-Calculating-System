module ShaniKorshov_SivanWeinberg {
	requires javafx.controls;
	requires javafx.graphics;
	requires java.desktop;
	
	opens ShaniKorshov_SivanWeinberg to javafx.graphics, javafx.fxml;
}
